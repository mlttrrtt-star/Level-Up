import { supabase, isSupabaseConfigured } from './supabase'
import { UserProfile, SportProgress, Activity, Challenge, SportId } from '../types'
import { getRankByXp } from '../data/ranks'

// ---------- Helpers de mapping ----------

function mapProfile(row: any): UserProfile {
  return {
    id: row.id,
    email: row.email,
    username: row.username,
    avatarUrl: row.avatar_url ?? undefined,
    bio: row.bio ?? undefined,
    country: row.country ?? undefined,
    city: row.city ?? undefined,
    sports: (row.sports || []) as SportId[],
    initialLevel: row.initial_level || {},
    goals: row.goals || [],
    createdAt: row.created_at,
    privacy: row.privacy || {
      showCountry: true,
      showCity: false,
      showStats: true,
      showActivities: true,
    },
  }
}

function mapProgress(rows: any[]): Record<SportId, SportProgress> {
  const all: SportId[] = [
    'running', 'weightlifting', 'streetworkout',
    'football', 'tennis', 'boxing', 'basketball',
  ]
  const result = {} as Record<SportId, SportProgress>
  for (const sid of all) {
    const row = rows.find((r: any) => r.sport_id === sid)
    result[sid] = row
      ? {
          sportId: sid,
          xp: row.xp,
          rankId: row.rank_id,
          bestPerformances: row.best_performances || {},
          challengesCompleted: row.challenges_completed,
          personalRecords: row.personal_records || {},
          streak: row.streak,
          lastActivity: row.last_activity ?? undefined,
        }
      : {
          sportId: sid,
          xp: 0,
          rankId: 1,
          bestPerformances: {},
          challengesCompleted: 0,
          personalRecords: {},
          streak: 0,
        }
  }
  return result
}

function mapActivity(row: any): Activity {
  return {
    id: row.id,
    userId: row.user_id,
    sportId: row.sport_id,
    type: row.type,
    title: row.title,
    date: row.date,
    duration: row.duration,
    distance: row.distance ?? undefined,
    calories: row.calories ?? undefined,
    stats: row.stats || {},
    notes: row.notes ?? undefined,
    verified: row.verified,
    xpEarned: row.xp_earned,
    gpsTrack: row.gps_track ?? undefined,
  }
}

function mapChallenge(row: any): Challenge {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    sportId: row.sport_id,
    category: row.category,
    difficulty: row.difficulty,
    target: Number(row.target),
    unit: row.unit,
    xpReward: row.xp_reward,
    startsAt: row.starts_at,
    endsAt: row.ends_at,
    conditions: row.conditions || [],
  }
}

// ---------- Auth ----------

export async function apiSignUp(
  email: string,
  password: string,
  meta: { username: string; sports: SportId[] }
): Promise<{ user: UserProfile | null; error: string | null }> {
  if (!supabase) return { user: null, error: 'Supabase non configuré' }

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username: meta.username,
        sports: meta.sports,
      },
    },
  })

  if (error) return { user: null, error: error.message }
  if (!data.user) return { user: null, error: 'Inscription échouée' }

  // Le trigger crée le profil. On le récupère.
  const profile = await apiFetchProfile(data.user.id)
  return { user: profile, error: null }
}

export async function apiSignIn(
  email: string,
  password: string
): Promise<{ user: UserProfile | null; error: string | null }> {
  if (!supabase) return { user: null, error: 'Supabase non configuré' }

  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) return { user: null, error: error.message }
  if (!data.user) return { user: null, error: 'Connexion échouée' }

  const profile = await apiFetchProfile(data.user.id)
  return { user: profile, error: null }
}

export async function apiSignOut(): Promise<void> {
  if (!supabase) return
  await supabase.auth.signOut()
}

export async function apiGetSessionUserId(): Promise<string | null> {
  if (!supabase) return null
  const { data } = await supabase.auth.getSession()
  return data.session?.user?.id ?? null
}

// ---------- Profile & data ----------

export async function apiFetchProfile(userId: string): Promise<UserProfile | null> {
  if (!supabase) return null
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  if (error || !data) return null
  return mapProfile(data)
}

export async function apiUpdateProfile(
  userId: string,
  updates: Partial<UserProfile>
): Promise<boolean> {
  if (!supabase) return false
  const payload: Record<string, unknown> = {}
  if (updates.username !== undefined) payload.username = updates.username
  if (updates.bio !== undefined) payload.bio = updates.bio
  if (updates.country !== undefined) payload.country = updates.country
  if (updates.city !== undefined) payload.city = updates.city
  if (updates.sports !== undefined) payload.sports = updates.sports
  if (updates.goals !== undefined) payload.goals = updates.goals
  if (updates.privacy !== undefined) payload.privacy = updates.privacy
  if (updates.avatarUrl !== undefined) payload.avatar_url = updates.avatarUrl

  const { error } = await supabase.from('profiles').update(payload).eq('id', userId)
  return !error
}

export async function apiFetchProgress(userId: string): Promise<Record<SportId, SportProgress>> {
  if (!supabase) return {} as any
  const { data } = await supabase
    .from('sport_progress')
    .select('*')
    .eq('user_id', userId)
  return mapProgress(data || [])
}

export async function apiFetchActivities(userId: string, limit = 50): Promise<Activity[]> {
  if (!supabase) return []
  const { data } = await supabase
    .from('activities')
    .select('*')
    .eq('user_id', userId)
    .order('date', { ascending: false })
    .limit(limit)
  return (data || []).map(mapActivity)
}

export async function apiFetchChallenges(): Promise<Challenge[]> {
  if (!supabase) return []
  const { data } = await supabase
    .from('challenges')
    .select('*')
    .eq('is_active', true)
    .order('starts_at', { ascending: false })
  return (data || []).map(mapChallenge)
}

export async function apiAddActivity(
  userId: string,
  activity: Omit<Activity, 'id' | 'userId' | 'xpEarned'> & { xpEarned?: number }
): Promise<{ activity: Activity | null; newProgress: SportProgress | null; rankUp: boolean }> {
  if (!supabase) return { activity: null, newProgress: null, rankUp: false }

  // Calcul XP simple (même logique que le store local)
  let xpEarned = 20
  if (activity.duration) xpEarned += Math.floor(activity.duration / 60) * 2
  if (activity.distance) xpEarned += Math.floor(activity.distance / 100) * 3
  if (activity.verified) xpEarned = Math.floor(xpEarned * 1.2)

  const { data: actData, error: actError } = await supabase
    .from('activities')
    .insert({
      user_id: userId,
      sport_id: activity.sportId,
      type: activity.type,
      title: activity.title,
      date: activity.date,
      duration: activity.duration,
      distance: activity.distance ?? null,
      calories: activity.calories ?? null,
      stats: activity.stats || {},
      notes: activity.notes ?? null,
      verified: activity.verified,
      xp_earned: xpEarned,
      gps_track: activity.gpsTrack ?? null,
      is_public: false, // jamais public par défaut (sécurité)
    })
    .select()
    .single()

  if (actError || !actData) {
    console.error('addActivity error', actError)
    return { activity: null, newProgress: null, rankUp: false }
  }

  // Mettre à jour sport_progress
  const { data: progRows } = await supabase
    .from('sport_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('sport_id', activity.sportId)
    .maybeSingle()

  let oldXp = 0
  if (progRows) {
    oldXp = progRows.xp
    const newXp = oldXp + xpEarned
    const newRank = getRankByXp(newXp)
    await supabase
      .from('sport_progress')
      .update({
        xp: newXp,
        rank_id: newRank.id,
        last_activity: activity.date,
        streak: (progRows.streak || 0) + 1,
      })
      .eq('id', progRows.id)
  } else {
    const newRank = getRankByXp(xpEarned)
    await supabase.from('sport_progress').insert({
      user_id: userId,
      sport_id: activity.sportId,
      xp: xpEarned,
      rank_id: newRank.id,
      last_activity: activity.date,
      streak: 1,
    })
  }

  const progressMap = await apiFetchProgress(userId)
  const newProgress = progressMap[activity.sportId]
  const rankUp = getRankByXp(oldXp).id < getRankByXp(oldXp + xpEarned).id

  return {
    activity: mapActivity(actData),
    newProgress,
    rankUp,
  }
}

export async function apiCompleteChallenge(
  userId: string,
  challengeId: string,
  xpReward: number,
  sportId: SportId | 'all'
): Promise<{ rankUp: boolean; sportId?: SportId }> {
  if (!supabase) return { rankUp: false }

  await supabase.from('user_challenges').upsert({
    user_id: userId,
    challenge_id: challengeId,
    progress: 999999,
    completed: true,
    completed_at: new Date().toISOString(),
  })

  if (sportId === 'all') return { rankUp: false }

  const { data: prog } = await supabase
    .from('sport_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('sport_id', sportId)
    .maybeSingle()

  if (!prog) return { rankUp: false }

  const oldRank = getRankByXp(prog.xp)
  const newXp = prog.xp + xpReward
  const newRank = getRankByXp(newXp)

  await supabase
    .from('sport_progress')
    .update({
      xp: newXp,
      rank_id: newRank.id,
      challenges_completed: (prog.challenges_completed || 0) + 1,
    })
    .eq('id', prog.id)

  return {
    rankUp: newRank.id > oldRank.id,
    sportId,
  }
}

export { isSupabaseConfigured }
