import { createClient, SupabaseClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

/** true si les variables d'environnement Supabase sont présentes */
export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl.startsWith('https://') &&
  supabaseAnonKey.length > 20
)

let client: SupabaseClient | null = null

if (isSupabaseConfigured) {
  client = createClient(supabaseUrl!, supabaseAnonKey!, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
    },
  })
}

/**
 * Client Supabase.
 * null si non configuré → l'app reste en mode démo localStorage.
 */
export const supabase = client

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          username: string
          avatar_url: string | null
          bio: string | null
          country: string | null
          city: string | null
          sports: string[]
          initial_level: Record<string, number>
          goals: string[]
          privacy: {
            showCountry: boolean
            showCity: boolean
            showStats: boolean
            showActivities: boolean
          }
          is_premium: boolean
          role: string
          created_at: string
          updated_at: string
        }
        Insert: Partial<Database['public']['Tables']['profiles']['Row']> & {
          id: string
          email: string
          username: string
        }
        Update: Partial<Database['public']['Tables']['profiles']['Row']>
      }
      sport_progress: {
        Row: {
          id: string
          user_id: string
          sport_id: string
          xp: number
          rank_id: number
          best_performances: Record<string, number | string>
          challenges_completed: number
          personal_records: Record<string, number | string>
          streak: number
          last_activity: string | null
          created_at: string
          updated_at: string
        }
      }
      activities: {
        Row: {
          id: string
          user_id: string
          sport_id: string
          type: string
          title: string
          date: string
          duration: number
          distance: number | null
          calories: number | null
          stats: Record<string, number | string>
          notes: string | null
          verified: boolean
          xp_earned: number
          gps_track: { lat: number; lng: number; timestamp: number }[] | null
          is_public: boolean
          created_at: string
        }
      }
      challenges: {
        Row: {
          id: string
          title: string
          description: string
          sport_id: string
          category: string
          difficulty: number
          target: number
          unit: string
          xp_reward: number
          starts_at: string
          ends_at: string
          conditions: string[]
          is_active: boolean
          created_at: string
        }
      }
    }
  }
}
