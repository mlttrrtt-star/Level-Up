import { useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAppStore } from './stores/useAppStore'
import Layout from './components/Layout'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Profile from './pages/Profile'
import SportDashboard from './pages/SportDashboard'
import RunningTracker from './pages/RunningTracker'
import Challenges from './pages/Challenges'
import Leaderboard from './pages/Leaderboard'
import Settings from './pages/Settings'
import RankUpModal from './components/RankUpModal'
import Coach from './pages/Coach'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const isAuthenticated = useAppStore(s => s.isAuthenticated)
  const authLoading = useAppStore(s => s.authLoading)

  if (authLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-black-deep">
        <div className="text-center">
          <div className="w-10 h-10 border-2 border-violet-electric border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-gray-400">Chargement...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) return <Navigate to="/login" replace />
  return <>{children}</>
}

export default function App() {
  const showRankUp = useAppStore(s => s.showRankUp)
  const clearRankUp = useAppStore(s => s.clearRankUp)
  const initAuth = useAppStore(s => s.initAuth)
  const backendMode = useAppStore(s => s.backendMode)

  useEffect(() => {
    initAuth()
  }, [initAuth])

  return (
    <>
      {/* Indicateur discret du mode backend */}
      {import.meta.env.DEV && (
        <div className="fixed top-0 right-0 z-[100] px-2 py-0.5 text-[9px] font-mono bg-black/80 text-gray-500 rounded-bl">
          {backendMode === 'supabase' ? 'SUPABASE' : 'LOCAL DEMO'}
        </div>
      )}

      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/sport/:sportId" element={<SportDashboard />} />
          <Route path="/running/track" element={<RunningTracker />} />
          <Route path="/challenges" element={<Challenges />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/coach" element={<Coach />} />
          <Route path="/settings" element={<Settings />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      {showRankUp && (
        <RankUpModal
          rankName={showRankUp.rankName}
          sportId={showRankUp.sportId}
          onClose={clearRankUp}
        />
      )}
    </>
  )
}
