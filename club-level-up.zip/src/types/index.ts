export type SportId = 
  | 'running' 
  | 'weightlifting' 
  | 'streetworkout' 
  | 'football' 
  | 'tennis' 
  | 'boxing' 
  | 'basketball';

export interface Rank {
  id: number;
  name: string;
  minXp: number;
  color: string;
  description: string;
  emblem: string; // emoji or icon key
}

export interface UserProfile {
  id: string;
  email: string;
  username: string;
  avatarUrl?: string;
  bio?: string;
  country?: string;
  city?: string;
  sports: SportId[];
  initialLevel: Record<SportId, number>;
  goals: string[];
  createdAt: string;
  privacy: {
    showCountry: boolean;
    showCity: boolean;
    showStats: boolean;
    showActivities: boolean;
  };
}

export interface SportProgress {
  sportId: SportId;
  xp: number;
  rankId: number;
  bestPerformances: Record<string, number | string>;
  challengesCompleted: number;
  personalRecords: Record<string, number | string>;
  streak: number;
  lastActivity?: string;
}

export interface Activity {
  id: string;
  userId: string;
  sportId: SportId;
  type: string;
  title: string;
  date: string;
  duration: number; // seconds
  distance?: number; // meters
  calories?: number;
  stats: Record<string, number | string>;
  notes?: string;
  verified: boolean;
  xpEarned: number;
  gpsTrack?: { lat: number; lng: number; timestamp: number }[];
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  sportId: SportId | 'all';
  category: 'daily' | 'weekly' | 'monthly' | 'community' | 'premium';
  difficulty: 1 | 2 | 3 | 4 | 5;
  target: number;
  unit: string;
  xpReward: number;
  startsAt: string;
  endsAt: string;
  conditions: string[];
  participants?: number;
  completed?: boolean;
  progress?: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: string;
}

export interface Giveaway {
  id: string;
  title: string;
  description: string;
  sportId: SportId;
  prize: string;
  endsAt: string;
  status: 'upcoming' | 'active' | 'ended' | 'disabled';
  participants: number;
  winnerId?: string;
}
