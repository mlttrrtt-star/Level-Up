import { Rank } from '../types';

export const RANKS: Rank[] = [
  {
    id: 1,
    name: 'ÉVEIL',
    minXp: 0,
    color: '#6B7280',
    description: 'Le début du voyage. Tout grand athlète a commencé ici.',
    emblem: '🌱',
  },
  {
    id: 2,
    name: 'IMPULSION',
    minXp: 600,
    color: '#8B5CF6',
    description: 'La première étincelle. Tu as franchi le pas.',
    emblem: '⚡',
  },
  {
    id: 3,
    name: 'ÉLAN',
    minXp: 1800,
    color: '#A78BFA',
    description: 'La dynamique s\'installe. La régularité paie.',
    emblem: '🚀',
  },
  {
    id: 4,
    name: 'ASCENSION',
    minXp: 4000,
    color: '#C4B5FD',
    description: 'Tu montes. Les obstacles deviennent des marches.',
    emblem: '⛰️',
  },
  {
    id: 5,
    name: 'DÉTERMINATION',
    minXp: 7500,
    color: '#DDD6FE',
    description: 'Rien ne t\'arrête. La volonté forge le champion.',
    emblem: '🔥',
  },
  {
    id: 6,
    name: 'PUISSANCE',
    minXp: 12000,
    color: '#F0ABFC',
    description: 'La force pure. Ton corps et ton esprit s\'alignent.',
    emblem: '💪',
  },
  {
    id: 7,
    name: 'DOMINANCE',
    minXp: 19000,
    color: '#E879F9',
    description: 'Tu domines ta discipline. Les autres te regardent.',
    emblem: '👑',
  },
  {
    id: 8,
    name: 'ÉLITE',
    minXp: 29000,
    color: '#D946EF',
    description: 'L\'élite. Peu atteignent ce niveau d\'excellence.',
    emblem: '💎',
  },
  {
    id: 9,
    name: 'LÉGENDE',
    minXp: 43000,
    color: '#C026D3',
    description: 'Une légende vivante. Ton nom inspire les autres.',
    emblem: '🌟',
  },
  {
    id: 10,
    name: 'ASCENDANT',
    minXp: 65000,
    color: '#FF00FF',
    description: 'Le sommet absolu. Tu as transcendu les limites. ASCENDANT.',
    emblem: '♾️',
  },
];

export function getRankByXp(xp: number): Rank {
  let current = RANKS[0];
  for (const rank of RANKS) {
    if (xp >= rank.minXp) {
      current = rank;
    } else {
      break;
    }
  }
  return current;
}

export function getNextRank(xp: number): Rank | null {
  const current = getRankByXp(xp);
  const nextIndex = RANKS.findIndex(r => r.id === current.id) + 1;
  return nextIndex < RANKS.length ? RANKS[nextIndex] : null;
}

export function getRankProgress(xp: number): { current: Rank; next: Rank | null; progress: number; xpToNext: number } {
  const current = getRankByXp(xp);
  const next = getNextRank(xp);
  if (!next) {
    return { current, next: null, progress: 100, xpToNext: 0 };
  }
  const range = next.minXp - current.minXp;
  const progressInRank = xp - current.minXp;
  const progress = Math.min(100, Math.round((progressInRank / range) * 100));
  return {
    current,
    next,
    progress,
    xpToNext: next.minXp - xp,
  };
}
