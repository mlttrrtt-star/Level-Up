import { SportId } from '../types';

export interface SportMeta {
  id: SportId;
  name: string;
  nameFr: string;
  icon: string;
  color: string;
  description: string;
  metrics: string[];
}

export const SPORTS: SportMeta[] = [
  {
    id: 'running',
    name: 'Running',
    nameFr: 'Course à pied',
    icon: '🏃',
    color: '#22C55E',
    description: 'Suivi GPS, allure, distance, records.',
    metrics: ['distance', 'duration', 'pace', 'speed', 'calories'],
  },
  {
    id: 'weightlifting',
    name: 'Weightlifting',
    nameFr: 'Musculation',
    icon: '🏋️',
    color: '#EF4444',
    description: 'Séries, charges, progression, programmes.',
    metrics: ['sets', 'reps', 'weight', 'volume'],
  },
  {
    id: 'streetworkout',
    name: 'Street Workout',
    nameFr: 'Street Workout',
    icon: '🤸',
    color: '#F59E0B',
    description: 'Tractions, muscle-ups, figures, force.',
    metrics: ['reps', 'holdTime', 'difficulty'],
  },
  {
    id: 'football',
    name: 'Football',
    nameFr: 'Football',
    icon: '⚽',
    color: '#3B82F6',
    description: 'Jongles, matchs, équipes, tournois.',
    metrics: ['juggles', 'goals', 'assists', 'matches'],
  },
  {
    id: 'tennis',
    name: 'Tennis',
    nameFr: 'Tennis',
    icon: '🎾',
    color: '#EAB308',
    description: 'Entraînements, matchs, stats techniques.',
    metrics: ['matches', 'wins', 'aces', 'duration'],
  },
  {
    id: 'boxing',
    name: 'Boxing',
    nameFr: 'Boxe',
    icon: '🥊',
    color: '#DC2626',
    description: 'Séances, endurance, technique, sparring.',
    metrics: ['rounds', 'duration', 'punches', 'intensity'],
  },
  {
    id: 'basketball',
    name: 'Basketball',
    nameFr: 'Basketball',
    icon: '🏀',
    color: '#F97316',
    description: 'Tirs, points, rebonds, défis.',
    metrics: ['points', 'rebounds', 'assists', 'shots'],
  },
];

export function getSport(id: SportId): SportMeta {
  return SPORTS.find(s => s.id === id) || SPORTS[0];
}
