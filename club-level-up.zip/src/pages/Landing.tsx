import { Link } from 'react-router-dom'
import { ArrowRight, Trophy, Zap, Target, Users } from 'lucide-react'
import { RANKS } from '../data/ranks'

export default function Landing() {
  return (
    <div className="min-h-dvh bg-black-deep">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-violet-dark/40 via-transparent to-black-deep pointer-events-none" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-violet-electric/10 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="relative max-w-5xl mx-auto px-4 pt-16 pb-20 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-electric/10 border border-violet-electric/30 text-violet-glow text-xs font-medium mb-8">
            <Zap size={14} />
            Application sportive gamifiée
          </div>

          <img 
            src="/logo.jpg" 
            alt="Club Level Up" 
            className="w-28 h-28 mx-auto mb-6 rounded-2xl shadow-glow object-cover"
          />

          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mb-4">
            <span className="text-gradient">CLUB LEVEL UP</span>
          </h1>
          
          <p className="text-xl sm:text-2xl text-gray-300 font-medium mb-3">
            Entraîne-toi. Progresse. Prouve-le.
          </p>
          
          <p className="text-gray-400 max-w-xl mx-auto mb-10 text-sm sm:text-base">
            La plateforme qui transforme tes performances sportives en progression mesurable, 
            rangs exclusifs et défis motivants. Course, musculation, street workout, football et plus.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/register"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-violet-electric hover:bg-violet-deep text-white font-semibold transition-all shadow-glow hover:shadow-glow-lg"
            >
              Commencer gratuitement
              <ArrowRight size={18} />
            </Link>
            <Link
              to="/login"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl border border-white/20 hover:border-violet-electric/50 text-white font-medium transition-all"
            >
              Se connecter
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <h2 className="font-display text-2xl font-bold text-center mb-10 tracking-wide">
          POURQUOI CLUB LEVEL UP ?
        </h2>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Trophy, title: '10 Rangs exclusifs', desc: 'De Éveil à Ascendant. Une progression unique par discipline.' },
            { icon: Target, title: 'Défis motivants', desc: 'Quotidiens, hebdomadaires, communautaires. Gagne de l\'XP réel.' },
            { icon: Zap, title: 'Suivi intelligent', desc: 'GPS course, musculation, street workout, stats avancées.' },
            { icon: Users, title: 'Communauté', desc: 'Classements, amis, partage de records et compétitions.' },
          ].map((f, i) => (
            <div key={i} className="glass rounded-2xl p-5 card-hover">
              <div className="w-10 h-10 rounded-xl bg-violet-electric/20 flex items-center justify-center mb-3">
                <f.icon size={20} className="text-violet-glow" />
              </div>
              <h3 className="font-semibold mb-1">{f.title}</h3>
              <p className="text-sm text-gray-400">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ranks preview */}
      <section className="max-w-5xl mx-auto px-4 py-16">
        <h2 className="font-display text-2xl font-bold text-center mb-3 tracking-wide">
          LES 10 RANGS
        </h2>
        <p className="text-center text-gray-400 text-sm mb-10">
          Chaque discipline a sa propre progression. Deviens Ascendant.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {RANKS.map((rank) => (
            <div 
              key={rank.id}
              className="glass rounded-xl p-3 text-center card-hover"
            >
              <div className="text-2xl mb-1">{rank.emblem}</div>
              <div className="text-xs font-bold tracking-wider" style={{ color: rank.color }}>
                {rank.name}
              </div>
              <div className="text-[10px] text-gray-500 mt-0.5">
                {rank.minXp.toLocaleString()} XP
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-5xl mx-auto px-4 py-16 text-center">
        <div className="glass rounded-3xl p-8 sm:p-12 border border-violet-electric/20">
          <h2 className="font-display text-2xl sm:text-3xl font-bold mb-3">
            Prêt à monter de niveau ?
          </h2>
          <p className="text-gray-400 mb-6 max-w-md mx-auto">
            Rejoins Club Level Up. Gratuit. Sans carte bancaire. Commence maintenant.
          </p>
          <Link
            to="/register"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-violet-electric hover:bg-violet-deep text-white font-semibold transition-all shadow-glow"
          >
            Créer mon compte
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      <footer className="border-t border-black-border py-8 text-center text-xs text-gray-600">
        <p>© 2026 Club Level Up — Entraîne-toi. Progresse. Prouve-le.</p>
        <p className="mt-1">Version 1.0 — PWA</p>
      </footer>
    </div>
  )
}
