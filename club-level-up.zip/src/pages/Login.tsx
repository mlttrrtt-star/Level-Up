import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { isSupabaseConfigured } from '../lib/supabase'
import { Mail, Lock, ArrowRight, AlertCircle } from 'lucide-react'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const login = useAppStore(s => s.login)
  const authError = useAppStore(s => s.authError)
  const authLoading = useAppStore(s => s.authLoading)
  const clearAuthError = useAppStore(s => s.clearAuthError)
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    clearAuthError()
    const success = await login(email, password)
    if (success) {
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-dvh flex items-center justify-center px-4 bg-black-deep">
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[400px] h-[400px] bg-violet-electric/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/">
            <img src="/logo.jpg" alt="CLU" className="w-16 h-16 mx-auto rounded-xl shadow-glow object-cover mb-4" />
          </Link>
          <h1 className="font-display text-2xl font-bold tracking-wide">Connexion</h1>
          <p className="text-gray-400 text-sm mt-1">Retrouve ta progression</p>
        </div>

        <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-4">
          {authError && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm">
              <AlertCircle size={16} />
              {authError}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Email</label>
            <div className="relative">
              <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="toi@email.com"
                required
                autoComplete="email"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-black-deep border border-black-border focus:border-violet-electric outline-none text-sm transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Mot de passe</label>
            <div className="relative">
              <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                autoComplete="current-password"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-black-deep border border-black-border focus:border-violet-electric outline-none text-sm transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={authLoading}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-violet-electric hover:bg-violet-deep text-white font-semibold transition-all disabled:opacity-50"
          >
            {authLoading ? 'Connexion...' : 'Se connecter'}
            {!authLoading && <ArrowRight size={18} />}
          </button>

          <p className="text-center text-xs text-gray-500 pt-2">
            Pas encore de compte ?{' '}
            <Link to="/register" className="text-violet-glow hover:underline">S'inscrire</Link>
          </p>
        </form>

        <p className="text-center text-[10px] text-gray-600 mt-6">
          {isSupabaseConfigured
            ? 'Mode Supabase actif — comptes réels'
            : 'Mode démo local : n\'importe quel email + mot de passe ≥ 4 caractères'}
        </p>
      </div>
    </div>
  )
}
