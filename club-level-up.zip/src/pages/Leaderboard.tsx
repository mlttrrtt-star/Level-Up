import { useState } from 'react'
import { SPORTS } from '../data/sports'
import { RANKS } from '../data/ranks'
import { Trophy, Medal } from 'lucide-react'
import clsx from 'clsx'

// Demo leaderboard data
const DEMO_LEADERS = [
  { rank: 1, username: 'AscendantPro', xp: 72000, country: 'FR', sport: 'running' },
  { rank: 2, username: 'EliteRunner', xp: 48500, country: 'BE', sport: 'running' },
  { rank: 3, username: 'PowerLift_X', xp: 31200, country: 'FR', sport: 'weightlifting' },
  { rank: 4, username: 'StreetKing', xp: 27800, country: 'CH', sport: 'streetworkout' },
  { rank: 5, username: 'BoxeChampion', xp: 24100, country: 'FR', sport: 'boxing' },
  { rank: 6, username: 'TennisAce', xp: 19800, country: 'LU', sport: 'tennis' },
  { rank: 7, username: 'Baller_99', xp: 16500, country: 'FR', sport: 'basketball' },
  { rank: 8, username: 'FootJongleur', xp: 14200, country: 'BE', sport: 'football' },
  { rank: 9, username: 'RunFast', xp: 12100, country: 'FR', sport: 'running' },
  { rank: 10, username: 'NewAthlete', xp: 8900, country: 'FR', sport: 'weightlifting' },
]

function getRankForXp(xp: number) {
  let r = RANKS[0]
  for (const rank of RANKS) {
    if (xp >= rank.minXp) r = rank
    else break
  }
  return r
}

export default function Leaderboard() {
  const [scope, setScope] = useState<'global' | 'national'>('global')
  const [sportFilter, setSportFilter] = useState<string>('all')

  const filtered = sportFilter === 'all' 
    ? DEMO_LEADERS 
    : DEMO_LEADERS.filter(l => l.sport === sportFilter)

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="font-display text-xl font-bold tracking-wide flex items-center gap-2">
          <Trophy size={22} className="text-violet-glow" />
          CLASSEMENT
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Données de démonstration</p>
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setScope('global')}
          className={clsx(
            'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
            scope === 'global' ? 'bg-violet-electric text-white' : 'bg-black-card text-gray-400'
          )}
        >
          Mondial
        </button>
        <button
          onClick={() => setScope('national')}
          className={clsx(
            'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
            scope === 'national' ? 'bg-violet-electric text-white' : 'bg-black-card text-gray-400'
          )}
        >
          National
        </button>
        <button
          onClick={() => setSportFilter('all')}
          className={clsx(
            'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
            sportFilter === 'all' ? 'bg-violet-electric text-white' : 'bg-black-card text-gray-400'
          )}
        >
          Tous
        </button>
        {SPORTS.map(s => (
          <button
            key={s.id}
            onClick={() => setSportFilter(s.id)}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors',
              sportFilter === s.id ? 'bg-violet-electric text-white' : 'bg-black-card text-gray-400'
            )}
          >
            {s.icon} {s.nameFr}
          </button>
        ))}
      </div>

      {/* Podium */}
      <div className="grid grid-cols-3 gap-2 items-end">
        {[1, 0, 2].map((idx) => {
          const leader = filtered[idx]
          if (!leader) return <div key={idx} />
          const rank = getRankForXp(leader.xp)
          const isFirst = leader.rank === 1
          return (
            <div 
              key={leader.rank}
              className={clsx(
                'glass rounded-xl p-3 text-center',
                isFirst && 'border border-violet-electric/40 shadow-glow'
              )}
            >
              <div className={clsx('text-2xl mb-1', isFirst && 'text-3xl')}>
                {leader.rank === 1 ? '🥇' : leader.rank === 2 ? '🥈' : '🥉'}
              </div>
              <p className="text-xs font-semibold truncate">{leader.username}</p>
              <p className="text-[10px] font-bold mt-0.5" style={{ color: rank.color }}>
                {rank.name}
              </p>
              <p className="text-[10px] text-gray-500">{leader.xp.toLocaleString()} XP</p>
            </div>
          )
        })}
      </div>

      {/* Full list */}
      <div className="space-y-1">
        {filtered.map((leader) => {
          const rank = getRankForXp(leader.xp)
          const sport = SPORTS.find(s => s.id === leader.sport)
          return (
            <div key={leader.rank} className="glass rounded-xl px-4 py-3 flex items-center gap-3">
              <span className={clsx(
                'w-6 text-center text-sm font-bold',
                leader.rank <= 3 ? 'text-violet-glow' : 'text-gray-500'
              )}>
                {leader.rank}
              </span>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-electric/40 to-violet-deep/40 flex items-center justify-center text-xs font-bold">
                {leader.username[0]}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{leader.username}</p>
                <p className="text-[10px] text-gray-500">{sport?.icon} {rank.name}</p>
              </div>
              <span className="text-xs font-semibold text-violet-glow">
                {leader.xp.toLocaleString()}
              </span>
            </div>
          )
        })}
      </div>

      <p className="text-[10px] text-center text-gray-600">
        Classements réels nécessitent un backend (Supabase/Firebase). Données de démonstration uniquement.
      </p>
    </div>
  )
}
