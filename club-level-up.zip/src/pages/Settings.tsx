import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { LogOut, Shield, Trash2, Download, Eye } from 'lucide-react'

export default function Settings() {
  const user = useAppStore(s => s.user)
  const logout = useAppStore(s => s.logout)
  const updateProfile = useAppStore(s => s.updateProfile)
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const togglePrivacy = (key: keyof NonNullable<typeof user>['privacy']) => {
    if (!user) return
    updateProfile({
      privacy: {
        ...user.privacy,
        [key]: !user.privacy[key],
      },
    })
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <h1 className="font-display text-xl font-bold tracking-wide">PARAMÈTRES</h1>

      <section className="glass rounded-2xl p-4 space-y-1">
        <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-1">Compte</h2>
        <div className="px-3 py-2">
          <p className="text-sm font-medium">{user?.username}</p>
          <p className="text-xs text-gray-500">{user?.email}</p>
        </div>
      </section>

      <section className="glass rounded-2xl p-4 space-y-1">
        <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-1 flex items-center gap-1.5">
          <Eye size={12} /> Confidentialité
        </h2>
        
        {user && (['showCountry', 'showCity', 'showStats', 'showActivities'] as const).map(key => (
          <button
            key={key}
            onClick={() => togglePrivacy(key)}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-white/5 transition-colors"
          >
            <span className="text-sm">
              {key === 'showCountry' && 'Afficher le pays'}
              {key === 'showCity' && 'Afficher la ville'}
              {key === 'showStats' && 'Afficher les statistiques'}
              {key === 'showActivities' && 'Afficher les activités'}
            </span>
            <div className={`w-10 h-6 rounded-full transition-colors relative ${user.privacy[key] ? 'bg-violet-electric' : 'bg-black-border'}`}>
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${user.privacy[key] ? 'left-5' : 'left-1'}`} />
            </div>
          </button>
        ))}
      </section>

      <section className="glass rounded-2xl p-4 space-y-1">
        <h2 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 px-1 flex items-center gap-1.5">
          <Shield size={12} /> Données & Sécurité
        </h2>
        
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-white/5 text-left">
          <Download size={18} className="text-gray-400" />
          <div>
            <p className="text-sm">Exporter mes données</p>
            <p className="text-[10px] text-gray-500">RGPD — téléchargement JSON (à implémenter côté serveur)</p>
          </div>
        </button>

        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-white/5 text-left text-red-400">
          <Trash2 size={18} />
          <div>
            <p className="text-sm">Supprimer mon compte</p>
            <p className="text-[10px] text-red-400/60">Action irréversible (nécessite backend)</p>
          </div>
        </button>
      </section>

      <section className="glass rounded-2xl p-4 border border-amber-500/20">
        <h2 className="text-xs font-semibold text-amber-400/80 uppercase tracking-wider mb-2">Abonnement</h2>
        <p className="text-sm font-medium">Formule Gratuite</p>
        <p className="text-xs text-gray-500 mt-1">
          Premium (2,99 €/mois) : défis exclusifs, Coach avancé, stats enrichies, compétitions.
        </p>
        <p className="text-[10px] text-gray-600 mt-2">
          Paiement non activé. Architecture prête pour Stripe / Paddle / RevenueCat.
        </p>
      </section>

      <section className="text-[10px] text-gray-600 space-y-1 px-1">
        <p>• Géolocalisation désactivée par défaut — consentement explicite requis</p>
        <p>• Données stockées localement (localStorage) en mode démo</p>
        <p>• Pour la production : Supabase + conformité RGPD + règles mineurs</p>
        <p>• Giveaways désactivés jusqu'à validation légale et financement</p>
      </section>

      <button
        onClick={handleLogout}
        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-colors font-medium text-sm"
      >
        <LogOut size={18} />
        Se déconnecter
      </button>
    </div>
  )
}
