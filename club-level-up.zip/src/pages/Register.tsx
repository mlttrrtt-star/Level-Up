import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { isSupabaseConfigured } from '../lib/supabase'
import { SPORTS } from '../data/sports'
import { SportId } from '../types'
import { Mail, Lock, User, ArrowRight, AlertCircle, Check } from 'lucide-react'
import clsx from 'clsx'

export default function Register() {
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [selectedSports, setSelectedSports] = useState<SportId[]>(['running'])
  const register = useAppStore(s => s.register)
  const authError = useAppStore(s => s.authError)
  const authLoading = useAppStore(s => s.authLoading)
  const clearAuthError = useAppStore(s => s.clearAuthError)
  const navigate = useNavigate()

  const toggleSport = (id: SportId) => {
    setSelectedSports(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    )
  }

  const handleSubmit = async () => {
    if (selectedSports.length === 0) return
    clearAuthError()
    const success = await register({
      email,
      password,
      username,
      sports: selectedSports,
    })
    if (success) {
      navigate('/dashboard')
    }
  }

  return (
    <div className="min-h-dvh flex items-center justify-center px-4 py-8 bg-black-deep">
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[400px] h-[400px] bg-violet-electric/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative w-full max-w-md">
        <div className="text-center mb-6">
          <Link to="/">
            <img src="/logo.jpg" alt="CLU" className="w-14 h-14 mx-auto rounded-xl shadow-glow object-cover mb-3" />
          </Link>
          <h1 className="font-display text-2xl font-bold tracking-wide">Créer un compte</h1>
          <p className="text-gray-400 text-sm mt-1">Étape {step}/2</p>
        </div>

        <div className="flex gap-2 mb-6">
          <div className={clsx('h-1 flex-1 rounded-full', step >= 1 ? 'bg-violet-electric' : 'bg-black-border')} />
          <div className={clsx('h-1 flex-1 rounded-full', step >= 2 ? 'bg-violet-electric' : 'bg-black-border')} />
        </div>

        <div className="glass rounded-2xl p-6">
          {authError && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm mb-4">
              <AlertCircle size={16} />
              {authError}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">Pseudonyme</label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="text"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="TonPseudo"
                    required
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-black-deep border border-black-border focus:border-violet-electric outline-none text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">Email</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="toi@email.com"
                    required
                    autoComplete="email"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-black-deep border border-black-border focus:border-violet-electric outline-none text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-400 mb-1.5">Mot de passe</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Min. 6 caractères"
                    required
                    minLength={6}
                    autoComplete="new-password"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-black-deep border border-black-border focus:border-violet-electric outline-none text-sm"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!username || !email || password.length < 6) return
                  clearAuthError()
                  setStep(2)
                }}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-violet-electric hover:bg-violet-deep text-white font-semibold transition-all"
              >
                Continuer
                <ArrowRight size={18} />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-300 mb-2">Quels sports pratiques-tu ?</p>

              <div className="grid grid-cols-2 gap-2">
                {SPORTS.map(sport => (
                  <button
                    key={sport.id}
                    type="button"
                    onClick={() => toggleSport(sport.id)}
                    className={clsx(
                      'flex items-center gap-2 p-3 rounded-xl border text-left transition-all',
                      selectedSports.includes(sport.id)
                        ? 'border-violet-electric bg-violet-electric/15'
                        : 'border-black-border bg-black-deep hover:border-white/20'
                    )}
                  >
                    <span className="text-xl">{sport.icon}</span>
                    <span className="text-xs font-medium flex-1">{sport.nameFr}</span>
                    {selectedSports.includes(sport.id) && (
                      <Check size={16} className="text-violet-glow" />
                    )}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex-1 py-3 rounded-xl border border-black-border text-sm font-medium hover:bg-white/5"
                >
                  Retour
                </button>
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={authLoading || selectedSports.length === 0}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-violet-electric hover:bg-violet-deep text-white font-semibold transition-all disabled:opacity-50"
                >
                  {authLoading ? 'Création...' : 'Créer mon compte'}
                </button>
              </div>
            </div>
          )}

          <p className="text-center text-xs text-gray-500 pt-4">
            Déjà un compte ?{' '}
            <Link to="/login" className="text-violet-glow hover:underline">Se connecter</Link>
          </p>
        </div>

        <p className="text-center text-[10px] text-gray-600 mt-4">
          {isSupabaseConfigured
            ? 'Mode Supabase — un vrai compte sera créé'
            : 'Mode démo local (données dans le navigateur)'}
        </p>
      </div>
    </div>
  )
}
