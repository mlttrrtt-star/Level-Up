import { Link } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { SPORTS } from '../data/sports'
import { getRankProgress, RANKS } from '../data/ranks'
import { ArrowRight, Flame, Target, TrendingUp, Play } from 'lucide-react'
import { SportId } from '../types'

export default function Dashboard() {
  const user = useAppStore(s => s.user)
  const progress = useAppStore(s => s.progress)
  const activities = useAppStore(s => s.activities)
  const challenges = useAppStore(s => s.challenges)
  const getTotalXp = useAppStore(s => s.getTotalXp)

  const totalXp = getTotalXp()
  const { current, next, progress: rankProgress, xpToNext } = getRankProgress(totalXp)
  const activeChallenges = challenges.filter(c => !c.completed).slice(0, 3)
  const recentActivities = activities.slice(0, 5)

  const userSports = SPORTS.filter(s => user?.sports?.includes(s.id))

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-xl font-bold">
          Salut, <span className="text-gradient">{user?.username}</span>
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Prêt à progresser aujourd'hui ?</p>
      </div>

      {/* Overall Rank Card */}
      <div className="glass rounded-2xl p-5 border border-violet-electric/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-violet-electric/10 rounded-full blur-3xl" />
        <div className="relative flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-electric to-violet-deep flex items-center justify-center text-3xl shadow-glow">
            {current.emblem}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-lg tracking-wider" style={{ color: current.color }}>
                {current.name}
              </span>
              <span className="text-xs text-gray-500">Rang global</span>
            </div>
            <p className="text-2xl font-bold mt-0.5">{totalXp.toLocaleString()} <span className="text-sm text-gray-400 font-normal">XP</span></p>
            
            {next && (
              <div className="mt-2">
                <div className="flex justify-between text-xs text-gray-400 mb-1">
                  <span>Prochain : {next.name}</span>
                  <span>{xpToNext.toLocaleString()} XP</span>
                </div>
                <div className="h-1.5 bg-black-border rounded-full overflow-hidden">
                  <div className="h-full rank-progress rounded-full transition-all duration-500" style={{ width: `${rankProgress}%` }} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Link to="/running/track" className="glass rounded-xl p-4 card-hover flex flex-col items-center gap-2 text-center">
          <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
            <Play size={18} className="text-green-400" />
          </div>
          <span className="text-xs font-medium">Démarrer course</span>
        </Link>
        <Link to="/challenges" className="glass rounded-xl p-4 card-hover flex flex-col items-center gap-2 text-center">
          <div className="w-10 h-10 rounded-full bg-violet-electric/20 flex items-center justify-center">
            <Target size={18} className="text-violet-glow" />
          </div>
          <span className="text-xs font-medium">Défis</span>
        </Link>
        <Link to="/coach" className="glass rounded-xl p-4 card-hover flex flex-col items-center gap-2 text-center">
          <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
            <Flame size={18} className="text-amber-400" />
          </div>
          <span className="text-xs font-medium">Coach IA</span>
        </Link>
        <Link to="/leaderboard" className="glass rounded-xl p-4 card-hover flex flex-col items-center gap-2 text-center">
          <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
            <TrendingUp size={18} className="text-blue-400" />
          </div>
          <span className="text-xs font-medium">Classement</span>
        </Link>
      </div>

      {/* Sports */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold">Mes disciplines</h2>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          {userSports.map(sport => {
            const prog = progress[sport.id as SportId]
            const rankInfo = getRankProgress(prog.xp)
            return (
              <Link
                key={sport.id}
                to={`/sport/${sport.id}`}
                className="glass rounded-xl p-4 card-hover flex items-center gap-3"
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                  style={{ backgroundColor: `${sport.color}20` }}
                >
                  {sport.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-sm">{sport.nameFr}</span>
                    <span className="text-xs font-bold" style={{ color: rankInfo.current.color }}>
                      {rankInfo.current.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1 bg-black-border rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all"
                        style={{ 
                          width: `${rankInfo.progress}%`,
                          backgroundColor: sport.color 
                        }}
                      />
                    </div>
                    <span className="text-[10px] text-gray-500">{prog.xp} XP</span>
                  </div>
                </div>
                <ArrowRight size={16} className="text-gray-600" />
              </Link>
            )
          })}
        </div>
      </div>

      {/* Active challenges */}
      {activeChallenges.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold">Défis en cours</h2>
            <Link to="/challenges" className="text-xs text-violet-glow hover:underline">Voir tout</Link>
          </div>
          <div className="space-y-2">
            {activeChallenges.map(c => (
              <div key={c.id} className="glass rounded-xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-violet-electric/15 flex items-center justify-center text-lg">
                  {SPORTS.find(s => s.id === c.sportId)?.icon || '🎯'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{c.title}</p>
                  <p className="text-xs text-gray-500">+{c.xpReward} XP · {c.difficulty}/5</p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-violet-electric/15 text-violet-glow capitalize">
                  {c.category}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent activities */}
      <div>
        <h2 className="font-semibold mb-3">Activité récente</h2>
        {recentActivities.length === 0 ? (
          <div className="glass rounded-xl p-8 text-center">
            <p className="text-gray-500 text-sm">Aucune activité pour le moment</p>
            <Link to="/running/track" className="inline-flex items-center gap-1 mt-2 text-sm text-violet-glow hover:underline">
              Commencer une course <ArrowRight size={14} />
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {recentActivities.map(act => (
              <div key={act.id} className="glass rounded-xl p-3 flex items-center gap-3">
                <span className="text-xl">{SPORTS.find(s => s.id === act.sportId)?.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{act.title}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(act.date).toLocaleDateString('fr-FR')} · +{act.xpEarned} XP
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
