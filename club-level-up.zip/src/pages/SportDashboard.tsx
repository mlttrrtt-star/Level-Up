import { useParams, Link } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { getSport } from '../data/sports'
import { getRankProgress } from '../data/ranks'
import { SportId } from '../types'
import { ArrowLeft, Play, History } from 'lucide-react'

export default function SportDashboard() {
  const { sportId } = useParams<{ sportId: string }>()
  const progress = useAppStore(s => s.progress)
  const activities = useAppStore(s => s.activities)

  const sport = getSport(sportId as SportId)
  const prog = progress[sportId as SportId] || { xp: 0, rankId: 1, challengesCompleted: 0, streak: 0, bestPerformances: {}, personalRecords: {} }
  const rankInfo = getRankProgress(prog.xp)
  const sportActivities = activities.filter(a => a.sportId === sportId).slice(0, 10)

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center gap-3">
        <Link to="/dashboard" className="p-2 -ml-2 rounded-lg hover:bg-white/5">
          <ArrowLeft size={20} />
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-3xl">{sport.icon}</span>
          <div>
            <h1 className="font-display text-lg font-bold tracking-wide">{sport.nameFr.toUpperCase()}</h1>
            <p className="text-xs text-gray-500">{sport.description}</p>
          </div>
        </div>
      </div>

      {/* Rank */}
      <div className="glass rounded-2xl p-5 border border-violet-electric/15">
        <div className="flex items-center gap-4">
          <div className="text-4xl">{rankInfo.current.emblem}</div>
          <div className="flex-1">
            <p className="font-display font-bold text-lg" style={{ color: rankInfo.current.color }}>
              {rankInfo.current.name}
            </p>
            <p className="text-sm text-gray-400">{prog.xp.toLocaleString()} XP</p>
            {rankInfo.next && (
              <div className="mt-2">
                <div className="flex justify-between text-xs text-gray-500 mb-1">
                  <span>→ {rankInfo.next.name}</span>
                  <span>{rankInfo.xpToNext} XP</span>
                </div>
                <div className="h-1.5 bg-black-border rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all"
                    style={{ width: `${rankInfo.progress}%`, backgroundColor: sport.color }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 gap-3">
        {sportId === 'running' && (
          <Link
            to="/running/track"
            className="glass rounded-xl p-4 flex items-center gap-3 card-hover"
          >
            <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
              <Play size={18} className="text-green-400" />
            </div>
            <span className="text-sm font-medium">Démarrer</span>
          </Link>
        )}
        <div className="glass rounded-xl p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-violet-electric/20 flex items-center justify-center">
            <History size={18} className="text-violet-glow" />
          </div>
          <div>
            <p className="text-sm font-medium">{sportActivities.length} activités</p>
            <p className="text-[10px] text-gray-500">Historique</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-lg font-bold">{prog.challengesCompleted}</p>
          <p className="text-[10px] text-gray-500">Défis</p>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-lg font-bold">{prog.streak}</p>
          <p className="text-[10px] text-gray-500">Série</p>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-lg font-bold">{sportActivities.length}</p>
          <p className="text-[10px] text-gray-500">Séances</p>
        </div>
      </div>

      {/* History */}
      <div>
        <h2 className="font-semibold mb-3">Historique récent</h2>
        {sportActivities.length === 0 ? (
          <div className="glass rounded-xl p-6 text-center text-sm text-gray-500">
            Aucune activité dans cette discipline
          </div>
        ) : (
          <div className="space-y-2">
            {sportActivities.map(act => (
              <div key={act.id} className="glass rounded-xl p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{act.title}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(act.date).toLocaleDateString('fr-FR')} · {Math.floor(act.duration / 60)} min
                  </p>
                </div>
                <span className="text-xs font-semibold text-violet-glow">+{act.xpEarned} XP</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sport-specific note */}
      {sportId === 'weightlifting' && (
        <div className="glass rounded-xl p-4 text-sm text-gray-400">
          <p className="font-medium text-white mb-1">Module Musculation</p>
          <p>Bibliothèque d'exercices, séries/reps/charges, chronomètre et programmes — architecture prête. Interface de saisie complète à enrichir.</p>
        </div>
      )}
      {sportId === 'streetworkout' && (
        <div className="glass rounded-xl p-4 text-sm text-gray-400">
          <p className="font-medium text-white mb-1">Module Street Workout</p>
          <p>Tractions, muscle-ups, front lever, planche... Niveaux de difficulté et défis techniques prévus.</p>
        </div>
      )}
      {(sportId === 'football' || sportId === 'tennis' || sportId === 'boxing' || sportId === 'basketball') && (
        <div className="glass rounded-xl p-4 text-sm text-gray-400">
          <p className="font-medium text-white mb-1">Module {sport.nameFr}</p>
          <p>Tableau de bord, stats, défis et historique opérationnels. Fonctionnalités avancées (équipes, matchs, analyse vidéo) en architecture.</p>
        </div>
      )}
    </div>
  )
}
