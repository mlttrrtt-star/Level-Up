import { useAppStore } from '../stores/useAppStore'
import { SPORTS } from '../data/sports'
import { Check, Lock } from 'lucide-react'
import clsx from 'clsx'

export default function Challenges() {
  const challenges = useAppStore(s => s.challenges)
  const completeChallenge = useAppStore(s => s.completeChallenge)

  const categories = [
    { key: 'daily', label: 'Quotidiens' },
    { key: 'weekly', label: 'Hebdomadaires' },
    { key: 'monthly', label: 'Mensuels' },
    { key: 'community', label: 'Communauté' },
    { key: 'premium', label: 'Premium' },
  ] as const

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="font-display text-xl font-bold tracking-wide">DÉFIS</h1>
        <p className="text-sm text-gray-400 mt-0.5">Relevez des défis, gagnez de l'XP</p>
      </div>

      {categories.map(cat => {
        const items = challenges.filter(c => c.category === cat.key)
        if (items.length === 0 && cat.key !== 'premium') return null

        return (
          <div key={cat.key}>
            <h2 className="text-sm font-semibold text-gray-300 mb-2 flex items-center gap-2">
              {cat.label}
              {cat.key === 'premium' && <Lock size={12} className="text-amber-400" />}
            </h2>

            {cat.key === 'premium' ? (
              <div className="glass rounded-xl p-5 border border-amber-500/20 text-center">
                <Lock size={24} className="mx-auto text-amber-400 mb-2" />
                <p className="text-sm font-medium">Défis Premium</p>
                <p className="text-xs text-gray-500 mt-1">
                  Disponible avec l'abonnement Club Level Up (2,99 €/mois)
                </p>
                <p className="text-[10px] text-gray-600 mt-2">
                  Paiement non activé — architecture prête pour intégration Stripe/Paddle
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {items.map(c => {
                  const sport = SPORTS.find(s => s.id === c.sportId)
                  return (
                    <div 
                      key={c.id}
                      className={clsx(
                        'glass rounded-xl p-4 transition-all',
                        c.completed && 'opacity-60'
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 rounded-lg bg-violet-electric/15 flex items-center justify-center text-lg shrink-0">
                          {sport?.icon || '🎯'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium">{c.title}</p>
                            {c.completed && <Check size={14} className="text-green-400" />}
                          </div>
                          <p className="text-xs text-gray-500 mt-0.5">{c.description}</p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-black-deep text-gray-400">
                              Difficulté {c.difficulty}/5
                            </span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-violet-electric/15 text-violet-glow">
                              +{c.xpReward} XP
                            </span>
                            {c.participants && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-black-deep text-gray-400">
                                {c.participants} participants
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {!c.completed && (
                        <button
                          onClick={() => completeChallenge(c.id)}
                          className="mt-3 w-full py-2 rounded-lg bg-violet-electric/20 hover:bg-violet-electric/30 text-violet-glow text-xs font-medium transition-colors"
                        >
                          Marquer comme accompli (démo)
                        </button>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
