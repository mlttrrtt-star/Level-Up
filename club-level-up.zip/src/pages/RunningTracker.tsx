import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../stores/useAppStore'
import { Play, Pause, Square, MapPin, Clock, Gauge, Flame, AlertTriangle } from 'lucide-react'
import clsx from 'clsx'

type TrackerState = 'idle' | 'running' | 'paused' | 'finished'

interface Position {
  lat: number
  lng: number
  timestamp: number
  accuracy?: number
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000 // meters
  const toRad = (d: number) => d * Math.PI / 180
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}

export default function RunningTracker() {
  const [state, setState] = useState<TrackerState>('idle')
  const [positions, setPositions] = useState<Position[]>([])
  const [distance, setDistance] = useState(0) // meters
  const [duration, setDuration] = useState(0) // seconds
  const [error, setError] = useState('')
  const [permission, setPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt')
  
  const watchId = useRef<number | null>(null)
  const timerRef = useRef<number | null>(null)
  const startTime = useRef<number>(0)
  const pausedDuration = useRef<number>(0)
  const lastPos = useRef<Position | null>(null)

  const addActivity = useAppStore(s => s.addActivity)
  const navigate = useNavigate()

  const requestPermission = useCallback(async () => {
    if (!navigator.geolocation) {
      setError('Géolocalisation non supportée par ce navigateur')
      setPermission('denied')
      return
    }
    try {
      // Request permission by getting current position
      await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
        })
      })
      setPermission('granted')
      setError('')
    } catch (err: any) {
      setPermission('denied')
      if (err.code === 1) {
        setError('Permission de géolocalisation refusée. Active-la dans les paramètres du navigateur.')
      } else {
        setError('Impossible d\'obtenir la position GPS')
      }
    }
  }, [])

  useEffect(() => {
    requestPermission()
    return () => {
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current)
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [requestPermission])

  const startTracking = () => {
    if (permission !== 'granted') {
      requestPermission()
      return
    }
    
    setState('running')
    setPositions([])
    setDistance(0)
    setDuration(0)
    lastPos.current = null
    startTime.current = Date.now()
    pausedDuration.current = 0

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        const newPos: Position = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          timestamp: pos.timestamp,
          accuracy: pos.coords.accuracy,
        }

        if (lastPos.current) {
          const d = haversine(lastPos.current.lat, lastPos.current.lng, newPos.lat, newPos.lng)
          // Filter GPS noise: ignore jumps > 50m in short time or very inaccurate
          if (d < 50 && (pos.coords.accuracy || 100) < 50) {
            setDistance(prev => prev + d)
          }
        }
        lastPos.current = newPos
        setPositions(prev => [...prev, newPos])
      },
      (err) => {
        console.warn('GPS error', err)
      },
      {
        enableHighAccuracy: true,
        maximumAge: 1000,
        timeout: 10000,
      }
    )

    timerRef.current = window.setInterval(() => {
      setDuration(Math.floor((Date.now() - startTime.current - pausedDuration.current) / 1000))
    }, 1000)
  }

  const pauseTracking = () => {
    setState('paused')
    if (watchId.current !== null) {
      navigator.geolocation.clearWatch(watchId.current)
      watchId.current = null
    }
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
    pausedDuration.current += Date.now() - startTime.current - pausedDuration.current - duration * 1000
  }

  const resumeTracking = () => {
    setState('running')
    startTime.current = Date.now() - duration * 1000
    
    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        const newPos: Position = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          timestamp: pos.timestamp,
          accuracy: pos.coords.accuracy,
        }
        if (lastPos.current) {
          const d = haversine(lastPos.current.lat, lastPos.current.lng, newPos.lat, newPos.lng)
          if (d < 50 && (pos.coords.accuracy || 100) < 50) {
            setDistance(prev => prev + d)
          }
        }
        lastPos.current = newPos
        setPositions(prev => [...prev, newPos])
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
    )

    timerRef.current = window.setInterval(() => {
      setDuration(Math.floor((Date.now() - startTime.current) / 1000))
    }, 1000)
  }

  const stopTracking = () => {
    if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current)
    if (timerRef.current) clearInterval(timerRef.current)
    setState('finished')
  }

  const saveActivity = () => {
    const pace = distance > 0 ? (duration / 60) / (distance / 1000) : 0 // min/km
    const speed = duration > 0 ? (distance / 1000) / (duration / 3600) : 0 // km/h
    // Very rough calorie estimate (don't claim accuracy)
    const calories = Math.round((distance / 1000) * 60) // ~60 kcal/km rough

    addActivity({
      sportId: 'running',
      type: 'run',
      title: `Course — ${(distance / 1000).toFixed(2)} km`,
      date: new Date().toISOString(),
      duration,
      distance,
      calories,
      stats: {
        pace: pace.toFixed(2),
        speed: speed.toFixed(2),
        points: positions.length,
      },
      verified: positions.length > 5,
      gpsTrack: positions.map(p => ({ lat: p.lat, lng: p.lng, timestamp: p.timestamp })),
    })

    navigate('/dashboard')
  }

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    const sec = s % 60
    return h > 0 
      ? `${h}:${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`
      : `${m}:${sec.toString().padStart(2,'0')}`
  }

  const pace = distance > 0 && duration > 0 
    ? ((duration / 60) / (distance / 1000)).toFixed(2) 
    : '—'

  return (
    <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
      <div className="text-center">
        <h1 className="font-display text-xl font-bold tracking-wide">COURSE À PIED</h1>
        <p className="text-xs text-gray-500 mt-1">Suivi GPS réel</p>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-sm">
          <AlertTriangle size={18} className="shrink-0 mt-0.5" />
          <div>
            <p>{error}</p>
            <button onClick={requestPermission} className="underline mt-1 text-xs">Réessayer</button>
          </div>
        </div>
      )}

      {/* Stats display */}
      <div className="glass rounded-3xl p-6 text-center border border-violet-electric/20">
        <div className="text-5xl font-display font-bold text-gradient mb-1">
          {(distance / 1000).toFixed(2)}
        </div>
        <div className="text-sm text-gray-400 mb-6">kilomètres</div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <Clock size={16} className="mx-auto text-violet-glow mb-1" />
            <div className="text-lg font-semibold">{formatTime(duration)}</div>
            <div className="text-[10px] text-gray-500">Durée</div>
          </div>
          <div>
            <Gauge size={16} className="mx-auto text-violet-glow mb-1" />
            <div className="text-lg font-semibold">{pace}</div>
            <div className="text-[10px] text-gray-500">min/km</div>
          </div>
          <div>
            <Flame size={16} className="mx-auto text-violet-glow mb-1" />
            <div className="text-lg font-semibold">{Math.round((distance/1000)*60)}</div>
            <div className="text-[10px] text-gray-500">kcal (est.)</div>
          </div>
        </div>
      </div>

      {/* GPS status */}
      <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
        <MapPin size={14} className={permission === 'granted' ? 'text-green-400' : 'text-gray-600'} />
        {permission === 'granted' 
          ? `${positions.length} points GPS · Précision active`
          : permission === 'denied' 
            ? 'GPS non autorisé'
            : 'En attente de permission GPS'
        }
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4">
        {state === 'idle' && (
          <button
            onClick={startTracking}
            disabled={permission === 'denied'}
            className="w-20 h-20 rounded-full bg-violet-electric hover:bg-violet-deep flex items-center justify-center shadow-glow transition-all disabled:opacity-40"
          >
            <Play size={32} fill="white" className="ml-1" />
          </button>
        )}

        {state === 'running' && (
          <>
            <button
              onClick={pauseTracking}
              className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center"
            >
              <Pause size={28} className="text-amber-400" />
            </button>
            <button
              onClick={stopTracking}
              className="w-20 h-20 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center"
            >
              <Square size={28} className="text-red-400" fill="currentColor" />
            </button>
          </>
        )}

        {state === 'paused' && (
          <>
            <button
              onClick={resumeTracking}
              className="w-16 h-16 rounded-full bg-green-500/20 border border-green-500/40 flex items-center justify-center"
            >
              <Play size={28} className="text-green-400 ml-0.5" />
            </button>
            <button
              onClick={stopTracking}
              className="w-20 h-20 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center"
            >
              <Square size={28} className="text-red-400" fill="currentColor" />
            </button>
          </>
        )}

        {state === 'finished' && (
          <div className="flex flex-col items-center gap-3 w-full">
            <p className="text-sm text-gray-400">Course terminée</p>
            <button
              onClick={saveActivity}
              className="w-full py-3.5 rounded-xl bg-violet-electric hover:bg-violet-deep font-semibold shadow-glow"
            >
              Enregistrer (+XP)
            </button>
            <button
              onClick={() => setState('idle')}
              className="text-sm text-gray-500 hover:text-white"
            >
              Annuler
            </button>
          </div>
        )}
      </div>

      <p className="text-[10px] text-center text-gray-600 px-4">
        La géolocalisation nécessite ton autorisation explicite. 
        Le suivi en arrière-plan est limité par le navigateur. 
        Pour un suivi fiable, garde l'application ouverte.
      </p>
    </div>
  )
}
