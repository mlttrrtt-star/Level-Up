import { useState } from 'react'
import { useAppStore } from '../stores/useAppStore'
import { SPORTS } from '../data/sports'
import { getRankProgress } from '../data/ranks'
import { Zap, Send, AlertCircle } from 'lucide-react'
import { SportId } from '../types'

const SUGGESTIONS = [
  "Analyse ma progression en course",
  "Propose un entraînement musculation",
  "Comment améliorer ma régularité ?",
  "Quels sont mes points faibles ?",
]

export default function Coach() {
  const [messages, setMessages] = useState<{ role: 'user' | 'coach'; text: string }[]>([
    { 
      role: 'coach', 
      text: 'Salut ! Je suis ton Coach IA Club Level Up. Je peux analyser tes stats, proposer des entraînements et t\'aider à progresser. Que veux-tu travailler aujourd\'hui ?' 
    }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  const user = useAppStore(s => s.user)
  const progress = useAppStore(s => s.progress)
  const activities = useAppStore(s => s.activities)
  const getTotalXp = useAppStore(s => s.getTotalXp)

  const generateResponse = (query: string): string => {
    const totalXp = getTotalXp()
    const overall = getRankProgress(totalXp)
    const sportSummaries = (user?.sports || []).map(sid => {
      const p = progress[sid as SportId]
      const r = getRankProgress(p.xp)
      return `${SPORTS.find(s => s.id === sid)?.nameFr}: ${r.current.name} (${p.xp} XP, série ${p.streak})`
    }).join('\n')

    const lower = query.toLowerCase()

    if (lower.includes('progression') || lower.includes('analyse') || lower.includes('course')) {
      return `Voici mon analyse basée sur tes données actuelles :\n\n` +
        `Rang global : ${overall.current.name} (${totalXp} XP)\n` +
        `${sportSummaries}\n\n` +
        `Activités enregistrées : ${activities.length}\n\n` +
        `Conseils :\n` +
        `• Concentre-toi sur la régularité plutôt que le volume excessif\n` +
        `• Vise le prochain rang ${overall.next?.name || 'Ascendant'} en validant des défis\n` +
        `• Alterne intensité et récupération\n\n` +
        `Note : Ceci est une analyse basée sur les données locales. Une vraie IA (OpenAI/Claude) pourra être branchée plus tard pour des conseils personnalisés avancés.`
    }

    if (lower.includes('musculation') || lower.includes('entraînement')) {
      return `Proposition d'entraînement (niveau adapté) :\n\n` +
        `Séance Full Body — 45-60 min\n` +
        `1. Squats — 4×8-12\n` +
        `2. Développé couché / pompes — 4×8-12\n` +
        `3. Rowing / tractions — 4×8-12\n` +
        `4. Soulevé de terre roumain — 3×10\n` +
        `5. Gainage — 3×30-45s\n\n` +
        `Repos 90-120s entre les séries. Progressive overload : augmente charge ou reps chaque semaine.\n\n` +
        `⚠️ Ceci n'est pas un conseil médical. Adapte selon ton ressenti et consulte un professionnel si besoin.`
    }

    if (lower.includes('régularité') || lower.includes('série') || lower.includes('habitude')) {
      return `Pour construire la régularité :\n\n` +
        `1. Commence petit : 20-30 min, 3x/semaine suffit pour démarrer\n` +
        `2. Même créneau horaire chaque jour → automatisme\n` +
        `3. Prépare ton équipement la veille\n` +
        `4. Utilise les défis quotidiens de Club Level Up comme ancrage\n` +
        `5. Une séance manquée ≠ échec. Reprends le lendemain\n\n` +
        `Ta série actuelle max : ${Math.max(...Object.values(progress).map(p => p.streak), 0)} jours. Objectif : 7 jours consécutifs.`
    }

    if (lower.includes('faible') || lower.includes('point')) {
      return `Analyse des points d'attention :\n\n` +
        `D'après tes données, voici ce que je remarque :\n` +
        `• Nombre d'activités : ${activities.length} — ${activities.length < 5 ? 'encore peu de données, continue !' : 'bonne base'}\n` +
        `• Diversité des sports : ${(user?.sports || []).length} discipline(s)\n\n` +
        `Recommandation : enregistre plus d'activités pour affiner l'analyse. Plus j'ai de données, meilleurs seront les conseils.`
    }

    return `Je suis ton coach Club Level Up. Pose-moi des questions sur :\n` +
      `• Ton analyse de progression\n` +
      `• Des propositions d'entraînement\n` +
      `• La régularité et les habitudes\n` +
      `• Tes points faibles / axes d'amélioration\n\n` +
      `Architecture prête pour brancher une vraie API d'IA (OpenAI, Claude, etc.). Actuellement en mode règles + données locales.`
  }

  const send = (text?: string) => {
    const q = (text || input).trim()
    if (!q) return
    
    setMessages(prev => [...prev, { role: 'user', text: q }])
    setInput('')
    setLoading(true)

    // Simulate thinking
    setTimeout(() => {
      const response = generateResponse(q)
      setMessages(prev => [...prev, { role: 'coach', text: response }])
      setLoading(false)
    }, 800)
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 flex flex-col h-[calc(100dvh-8rem)]">
      <div className="mb-4">
        <h1 className="font-display text-xl font-bold tracking-wide flex items-center gap-2">
          <Zap size={22} className="text-violet-glow" />
          COACH IA
        </h1>
        <p className="text-xs text-gray-500 mt-0.5">Analyse locale · API IA prête à brancher</p>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 mb-4">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap ${
                m.role === 'user'
                  ? 'bg-violet-electric text-white rounded-br-md'
                  : 'glass rounded-bl-md'
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="glass rounded-2xl rounded-bl-md px-4 py-3 text-sm text-gray-400">
              Analyse en cours...
            </div>
          </div>
        )}
      </div>

      {/* Suggestions */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-2">
        {SUGGESTIONS.map(s => (
          <button
            key={s}
            onClick={() => send(s)}
            className="shrink-0 px-3 py-1.5 rounded-full bg-black-card border border-black-border text-xs text-gray-300 hover:border-violet-electric/40 transition-colors"
          >
            {s}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
          placeholder="Pose ta question..."
          className="flex-1 px-4 py-3 rounded-xl bg-black-card border border-black-border focus:border-violet-electric outline-none text-sm"
        />
        <button
          onClick={() => send()}
          disabled={loading || !input.trim()}
          className="w-12 h-12 rounded-xl bg-violet-electric hover:bg-violet-deep flex items-center justify-center disabled:opacity-40 transition-colors"
        >
          <Send size={18} />
        </button>
      </div>

      <div className="flex items-start gap-1.5 mt-2 text-[10px] text-gray-600">
        <AlertCircle size={12} className="shrink-0 mt-0.5" />
        <span>Pas de conseils médicaux. Les réponses sont générées localement à partir de tes stats. Connexion à une vraie IA prévue.</span>
      </div>
    </div>
  )
}
