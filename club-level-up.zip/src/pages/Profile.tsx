import { useAppStore } from '../stores/useAppStore'
import { SPORTS } from '../data/sports'
import { getRankProgress } from '../data/ranks'
import { SportId } from '../types'
import { MapPin, Calendar, Award, Flame } from 'lucide-react'

export default function Profile() {
  const user = useAppStore(s => s.user)
  const progress = useAppStore(s => s.progress)
  const activities = useAppStore(s => s.activities)
  const getTotalXp = useAppStore(s => s.getTotalXp)
  const getOverallRank = useAppStore(s => s.getOverallRank)

  if (!user) return null

  const totalXp = getTotalXp()
  const overallRank = getOverallRank()
  const memberSince = new Date(user.createdAt).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })
  const totalChallenges = Object.values(progress).reduce((s, p) => s + p.challengesCompleted, 0)
  const totalStreak = Math.max(...Object.values(progress).map(p => p.streak), 0)

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="glass rounded-2xl p-6 text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-violet-electric/20 to-transparent" />
        
        <div className="relative">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-violet-electric to-violet-deep flex items-center justify-center text-3xl font-bold border-4 border-black-deep shadow-glow">
            {user.username[0]?.toUpperCase()}
          </div>
          
          <h1 className="font-display text-xl font-bold mt-3 tracking-wide">{user.username}</h1>
          
          <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full bg-violet-electric/15 border border-violet-electric/30">
            <span className="text-lg">{overallRank.emblem}</span>
            <span className="text-sm font-bold" style={{ color: overallRank.color }}>
              {overallRank.name}
            </span>
          </div>

          {user.bio && <p className="text-sm text-gray-400 mt-3 max-w-xs mx-auto">{user.bio}</p>}

          <div className="flex items-center justify-center gap-4 mt-4 text-xs text-gray-500">
            {(user.city || user.country) && user.privacy.showCountry && (
              <span className="flex items-center gap-1">
                <MapPin size={12} />
                {[user.city, user.country].filter(Boolean).join(', ')}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Calendar size={12} />
              Membre depuis {memberSince}
            </span>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-xl font-bold text-violet-glow">{totalXp.toLocaleString()}</p>
          <p className="text-[10px] text-gray-500">XP Total</p>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-xl font-bold">{totalChallenges}</p>
          <p className="text-[10px] text-gray-500">Défis</p>
        </div>
        <div className="glass rounded-xl p-3 text-center">
          <p className="text-xl font-bold flex items-center justify-center gap-1">
            <Flame size={16} className="text-orange-400" />
            {totalStreak}
          </p>
          <p className="text-[10px] text-gray-500">Série</p>
        </div>
      </div>

      {/* Ranks by sport */}
      <div>
        <h2 className="font-semibold mb-3 flex items-center gap-2">
          <Award size={16} className="text-violet-glow" />
          Rangs par discipline
        </h2>
        <div className="space-y-2">
          {user.sports.map(sportId => {
            const sport = SPORTS.find(s => s.id === sportId)!
            const prog = progress[sportId as SportId]
            const rankInfo = getRankProgress(prog.xp)
            return (
              <div key={sportId} className="glass rounded-xl p-3 flex items-center gap-3">
                <span className="text-2xl">{sport.icon}</span>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{sport.nameFr}</span>
                    <span className="text-xs font-bold" style={{ color: rankInfo.current.color }}>
                      {rankInfo.current.emblem} {rankInfo.current.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1 bg-black-border rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full"
                        style={{ width: `${rankInfo.progress}%`, backgroundColor: sport.color }}
                      />
                    </div>
                    <span className="text-[10px] text-gray-500 w-16 text-right">{prog.xp} XP</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Activity count */}
      <div className="glass rounded-xl p-4 text-center">
        <p className="text-2xl font-bold">{activities.length}</p>
        <p className="text-xs text-gray-500">Activités enregistrées</p>
      </div>
    </div>
  )
}
