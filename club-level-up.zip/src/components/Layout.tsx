import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { 
  Home, Trophy, Target, User, Settings, 
  Zap, Activity, Menu, X 
} from 'lucide-react'
import { useState } from 'react'
import { useAppStore } from '../stores/useAppStore'
import { getRankProgress } from '../data/ranks'
import clsx from 'clsx'

const navItems = [
  { to: '/dashboard', icon: Home, label: 'Accueil' },
  { to: '/challenges', icon: Target, label: 'Défis' },
  { to: '/leaderboard', icon: Trophy, label: 'Classement' },
  { to: '/coach', icon: Zap, label: 'Coach IA' },
  { to: '/profile', icon: User, label: 'Profil' },
]

export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false)
  const user = useAppStore(s => s.user)
  const getTotalXp = useAppStore(s => s.getTotalXp)
  const navigate = useNavigate()

  const totalXp = getTotalXp()
  const { current, progress } = getRankProgress(totalXp)

  return (
    <div className="min-h-dvh flex flex-col bg-black-deep">
      {/* Top bar */}
      <header className="sticky top-0 z-40 glass safe-top border-b border-black-border">
        <div className="flex items-center justify-between px-4 h-14">
          <div className="flex items-center gap-3">
            <button 
              className="md:hidden p-2 -ml-2 rounded-lg hover:bg-white/5"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
            <div 
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => navigate('/dashboard')}
            >
              <img src="/logo.jpg" alt="CLU" className="w-8 h-8 rounded-lg object-cover" />
              <span className="font-display font-bold text-sm tracking-wider hidden sm:block text-gradient">
                CLUB LEVEL UP
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-xs text-violet-glow font-medium">{current.name}</span>
              <span className="text-[10px] text-gray-400">{totalXp.toLocaleString()} XP</span>
            </div>
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-electric to-violet-deep flex items-center justify-center text-sm font-bold border-2 border-violet-glow/50">
              {user?.username?.[0]?.toUpperCase() || 'A'}
            </div>
          </div>
        </div>

        {/* XP Progress bar */}
        <div className="h-0.5 bg-black-border">
          <div 
            className="h-full rank-progress transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </header>

      {/* Mobile menu overlay */}
      {menuOpen && (
        <div className="fixed inset-0 z-30 md:hidden">
          <div className="absolute inset-0 bg-black/80" onClick={() => setMenuOpen(false)} />
          <nav className="absolute top-14 left-0 bottom-0 w-64 bg-black-soft border-r border-black-border p-4 space-y-1">
            {navItems.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setMenuOpen(false)}
                className={({ isActive }) => clsx(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                  isActive 
                    ? 'bg-violet-electric/20 text-violet-glow' 
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                )}
              >
                <item.icon size={20} />
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/settings"
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) => clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors',
                isActive 
                  ? 'bg-violet-electric/20 text-violet-glow' 
                  : 'text-gray-400 hover:bg-white/5 hover:text-white'
              )}
            >
              <Settings size={20} />
              Paramètres
            </NavLink>
          </nav>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-20 md:pb-6">
        <Outlet />
      </main>

      {/* Bottom navigation - mobile */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 glass border-t border-black-border safe-bottom md:hidden">
        <div className="flex items-center justify-around h-16">
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => clsx(
                'flex flex-col items-center justify-center gap-0.5 w-16 h-full transition-colors',
                isActive ? 'text-violet-electric' : 'text-gray-500'
              )}
            >
              <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  )
}
