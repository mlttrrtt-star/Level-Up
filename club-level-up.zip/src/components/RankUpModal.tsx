import { useEffect } from 'react'
import { SportId } from '../types'
import { getSport } from '../data/sports'
import { X } from 'lucide-react'

interface Props {
  rankName: string
  sportId: SportId
  onClose: () => void
}

export default function RankUpModal({ rankName, sportId, onClose }: Props) {
  const sport = getSport(sportId)

  useEffect(() => {
    const timer = setTimeout(onClose, 6000)
    return () => clearTimeout(timer)
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
      <div className="relative w-full max-w-sm animate-rank-up">
        <button 
          onClick={onClose}
          className="absolute -top-2 -right-2 p-2 rounded-full bg-black-card border border-black-border text-gray-400 hover:text-white z-10"
        >
          <X size={18} />
        </button>

        <div className="bg-gradient-to-b from-violet-dark to-black-card rounded-3xl border border-violet-electric/40 p-8 text-center shadow-glow-lg overflow-hidden">
          {/* Glow effect */}
          <div className="absolute inset-0 bg-gradient-to-t from-violet-electric/10 to-transparent pointer-events-none" />
          
          <div className="relative">
            <div className="text-6xl mb-4 animate-float">{sport.icon}</div>
            
            <p className="text-sm uppercase tracking-[0.3em] text-violet-glow mb-2 font-medium">
              Nouveau Rang
            </p>
            
            <h2 className="font-display text-3xl font-bold text-white mb-1 tracking-wider">
              {rankName}
            </h2>
            
            <p className="text-gray-400 text-sm mb-6">
              {sport.nameFr}
            </p>

            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-violet-electric/20 border border-violet-electric/40">
              <img src="/logo.jpg" alt="CLU" className="w-5 h-5 rounded object-cover" />
              <span className="text-xs font-medium text-violet-glow">CLUB LEVEL UP</span>
            </div>

            <p className="mt-6 text-xs text-gray-500">
              Continue. Progresse. Prouve-le.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
