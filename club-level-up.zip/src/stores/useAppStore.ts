import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { UserProfile, SportProgress, Activity, Challenge, Badge, SportId } from '../types'
import { getRankByXp } from '../data/ranks'
import {
  isSupabaseConfigured,
  apiSignIn,
  apiSignUp,
  apiSignOut,
  apiGetSessionUserId,
  apiFetchProfile,
  apiFetchProgress,
  apiFetchActivities,
  apiFetchChallenges,
  apiUpdateProfile,
  apiAddActivity,
  apiCompleteChallenge,
} from '../lib/api'

interface AppState {
  // Mode
  backendMode: 'local' | 'supabase'

  // Auth
  isAuthenticated: boolean
  user: UserProfile | null
  authLoading: boolean
  authError: string | null

  // Progress per sport
  progress: Record<SportId, SportProgress>

  // Activities
  activities: Activity[]

  // Challenges
  challenges: Challenge[]

  // Badges
  badges: Badge[]

  // UI
  activeSport: SportId | null
  showRankUp: { rankName: string; sportId: SportId } | null

  // Actions
  initAuth: () => Promise<void>
  login: (email: string, password: string) => Promise<boolean>
  register: (data: Partial<UserProfile> & { password: string }) => Promise<boolean>
  logout: () => Promise<void>
  updateProfile: (data: Partial<UserProfile>) => Promise<void>
  loadUserData: (userId: string) => Promise<void>

  addActivity: (activity: Omit<Activity, 'id' | 'userId' | 'xpEarned'>) => Promise<void>
  completeChallenge: (challengeId: string) => Promise<void>

  setActiveSport: (sport: SportId | null) => void
  clearRankUp: () => void
  clearAuthError: () => void

  // Computed helpers
  getTotalXp: () => number
  getOverallRank: () => ReturnType<typeof getRankByXp>
}

const defaultProgress = (sportId: SportId): SportProgress => ({
  sportId,
  xp: 0,
  rankId: 1,
  bestPerformances: {},
  challengesCompleted: 0,
  personalRecords: {},
  streak: 0,
})

const initialProgress: Record<SportId, SportProgress> = {
  running: defaultProgress('running'),
  weightlifting: defaultProgress('weightlifting'),
  streetworkout: defaultProgress('streetworkout'),
  football: defaultProgress('football'),
  tennis: defaultProgress('tennis'),
  boxing: defaultProgress('boxing'),
  basketball: defaultProgress('basketball'),
}

// Défis de démo (mode local uniquement)
const demoChallenges: Challenge[] = [
  {
    id: 'daily-1',
    title: 'Course matinale',
    description: "Cours au moins 3 km aujourd'hui",
    sportId: 'running',
    category: 'daily',
    difficulty: 2,
    target: 3000,
    unit: 'm',
    xpReward: 80,
    startsAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 86400000).toISOString(),
    conditions: ['Distance minimale 3km', 'Validation GPS'],
  },
  {
    id: 'weekly-1',
    title: 'Volume musculation',
    description: 'Complète 5 séances de musculation cette semaine',
    sportId: 'weightlifting',
    category: 'weekly',
    difficulty: 3,
    target: 5,
    unit: 'séances',
    xpReward: 250,
    startsAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 7 * 86400000).toISOString(),
    conditions: ['Minimum 4 exercices par séance'],
  },
  {
    id: 'daily-2',
    title: '50 pompes',
    description: 'Réalise 50 pompes (en plusieurs séries si besoin)',
    sportId: 'streetworkout',
    category: 'daily',
    difficulty: 2,
    target: 50,
    unit: 'reps',
    xpReward: 60,
    startsAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 86400000).toISOString(),
    conditions: ['Forme correcte'],
  },
  {
    id: 'community-1',
    title: 'Défi communautaire : 100km collectifs',
    description: 'La communauté doit atteindre 100km de course cette semaine',
    sportId: 'running',
    category: 'community',
    difficulty: 3,
    target: 100000,
    unit: 'm',
    xpReward: 150,
    startsAt: new Date().toISOString(),
    endsAt: new Date(Date.now() + 7 * 86400000).toISOString(),
    conditions: ['Participation active'],
    participants: 1284,
  },
]

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      backendMode: isSupabaseConfigured ? 'supabase' : 'local',
      isAuthenticated: false,
      user: null,
      authLoading: false,
      authError: null,
      progress: initialProgress,
      activities: [],
      challenges: demoChallenges,
      badges: [],
      activeSport: null,
      showRankUp: null,

      initAuth: async () => {
        if (!isSupabaseConfigured) {
          // Mode local : l'état persisté suffit
          return
        }
        set({ authLoading: true })
        try {
          const userId = await apiGetSessionUserId()
          if (userId) {
            await get().loadUserData(userId)
            set({ isAuthenticated: true })
          } else {
            set({ isAuthenticated: false, user: null })
          }
        } catch (e) {
          console.error('initAuth', e)
          set({ isAuthenticated: false, user: null })
        } finally {
          set({ authLoading: false })
        }
      },

      loadUserData: async (userId: string) => {
        const [profile, progress, activities, challenges] = await Promise.all([
          apiFetchProfile(userId),
          apiFetchProgress(userId),
          apiFetchActivities(userId),
          apiFetchChallenges(),
        ])
        if (profile) {
          set({
            user: profile,
            progress: Object.keys(progress).length ? progress : initialProgress,
            activities,
            challenges: challenges.length ? challenges : demoChallenges,
          })
        }
      },

      login: async (email, password) => {
        set({ authError: null, authLoading: true })

        // --- Mode Supabase ---
        if (isSupabaseConfigured) {
          const { user, error } = await apiSignIn(email, password)
          if (error || !user) {
            set({ authError: error || 'Connexion échouée', authLoading: false })
            return false
          }
          await get().loadUserData(user.id)
          set({ isAuthenticated: true, user, authLoading: false })
          return true
        }

        // --- Mode démo local ---
        if (email && password.length >= 4) {
          const demoUser: UserProfile = {
            id: 'user-demo-1',
            email,
            username: email.split('@')[0] || 'Athlete',
            sports: ['running', 'weightlifting'],
            initialLevel: {
              running: 2,
              weightlifting: 3,
              streetworkout: 1,
              football: 1,
              tennis: 1,
              boxing: 1,
              basketball: 1,
            },
            goals: ['Améliorer mon 5km', 'Prendre de la masse'],
            createdAt: new Date().toISOString(),
            privacy: {
              showCountry: true,
              showCity: false,
              showStats: true,
              showActivities: true,
            },
          }
          set({ isAuthenticated: true, user: demoUser, authLoading: false })
          return true
        }
        set({ authError: 'Email ou mot de passe incorrect', authLoading: false })
        return false
      },

      register: async (data) => {
        set({ authError: null, authLoading: true })

        if (isSupabaseConfigured) {
          if (!data.email || !data.password || data.password.length < 6) {
            set({ authError: 'Mot de passe minimum 6 caractères', authLoading: false })
            return false
          }
          const { user, error } = await apiSignUp(data.email, data.password, {
            username: data.username || data.email.split('@')[0] || 'Athlete',
            sports: data.sports || ['running'],
          })
          if (error || !user) {
            set({ authError: error || 'Inscription échouée', authLoading: false })
            return false
          }
          // Note : si confirmation email activée, l'utilisateur doit confirmer
          await get().loadUserData(user.id)
          set({ isAuthenticated: true, user, authLoading: false })
          return true
        }

        // Mode démo local
        if (data.email && data.password && data.password.length >= 6) {
          const newUser: UserProfile = {
            id: `user-${Date.now()}`,
            email: data.email,
            username: data.username || data.email.split('@')[0] || 'Nouveau',
            sports: data.sports || ['running'],
            initialLevel: data.initialLevel || {
              running: 1,
              weightlifting: 1,
              streetworkout: 1,
              football: 1,
              tennis: 1,
              boxing: 1,
              basketball: 1,
            },
            goals: data.goals || [],
            createdAt: new Date().toISOString(),
            privacy: {
              showCountry: true,
              showCity: false,
              showStats: true,
              showActivities: true,
            },
            ...data,
          }
          set({ isAuthenticated: true, user: newUser, authLoading: false })
          return true
        }
        set({ authError: 'Inscription invalide', authLoading: false })
        return false
      },

      logout: async () => {
        if (isSupabaseConfigured) {
          await apiSignOut()
        }
        set({
          isAuthenticated: false,
          user: null,
          progress: initialProgress,
          activities: [],
          challenges: isSupabaseConfigured ? [] : demoChallenges,
        })
      },

      updateProfile: async (data) => {
        const { user } = get()
        if (!user) return

        if (isSupabaseConfigured) {
          const ok = await apiUpdateProfile(user.id, data)
          if (ok) {
            set({ user: { ...user, ...data } })
          }
          return
        }
        set({ user: { ...user, ...data } })
      },

      addActivity: async (activityData) => {
        const { user, progress } = get()
        if (!user) return

        if (isSupabaseConfigured) {
          const { activity, newProgress, rankUp } = await apiAddActivity(user.id, activityData)
          if (activity) {
            set((state) => ({
              activities: [activity, ...state.activities],
              progress: newProgress
                ? { ...state.progress, [activity.sportId]: newProgress }
                : state.progress,
              showRankUp: rankUp
                ? {
                    rankName: getRankByXp(newProgress?.xp || 0).name,
                    sportId: activity.sportId,
                  }
                : null,
            }))
          }
          return
        }

        // Mode local
        let xpEarned = 20
        if (activityData.duration) xpEarned += Math.floor(activityData.duration / 60) * 2
        if (activityData.distance) xpEarned += Math.floor(activityData.distance / 100) * 3
        if (activityData.verified) xpEarned = Math.floor(xpEarned * 1.2)

        const activity: Activity = {
          ...activityData,
          id: `act-${Date.now()}`,
          userId: user.id,
          xpEarned,
        }

        const sportProg = { ...progress[activity.sportId] }
        const oldRank = getRankByXp(sportProg.xp)
        sportProg.xp += xpEarned
        const newRank = getRankByXp(sportProg.xp)
        sportProg.rankId = newRank.id
        sportProg.lastActivity = activity.date
        sportProg.streak += 1

        set({
          activities: [activity, ...get().activities],
          progress: { ...progress, [activity.sportId]: sportProg },
          showRankUp:
            newRank.id > oldRank.id
              ? { rankName: newRank.name, sportId: activity.sportId }
              : null,
        })
      },

      completeChallenge: async (challengeId) => {
        const { challenges, progress, user } = get()
        const challenge = challenges.find((c) => c.id === challengeId)
        if (!challenge || challenge.completed || !user) return

        if (isSupabaseConfigured) {
          const result = await apiCompleteChallenge(
            user.id,
            challengeId,
            challenge.xpReward,
            challenge.sportId
          )
          const updatedChallenges = challenges.map((c) =>
            c.id === challengeId ? { ...c, completed: true, progress: c.target } : c
          )
          if (result.rankUp && result.sportId) {
            const freshProgress = await apiFetchProgress(user.id)
            set({
              challenges: updatedChallenges,
              progress: freshProgress,
              showRankUp: {
                rankName: getRankByXp(freshProgress[result.sportId].xp).name,
                sportId: result.sportId,
              },
            })
          } else {
            set({ challenges: updatedChallenges })
            if (challenge.sportId !== 'all') {
              const freshProgress = await apiFetchProgress(user.id)
              set({ progress: freshProgress })
            }
          }
          return
        }

        // Mode local
        const updatedChallenges = challenges.map((c) =>
          c.id === challengeId ? { ...c, completed: true, progress: c.target } : c
        )

        if (challenge.sportId !== 'all') {
          const sportProg = { ...progress[challenge.sportId as SportId] }
          const oldRank = getRankByXp(sportProg.xp)
          sportProg.xp += challenge.xpReward
          sportProg.challengesCompleted += 1
          const newRank = getRankByXp(sportProg.xp)
          sportProg.rankId = newRank.id

          set({
            challenges: updatedChallenges,
            progress: { ...progress, [challenge.sportId]: sportProg },
            showRankUp:
              newRank.id > oldRank.id
                ? { rankName: newRank.name, sportId: challenge.sportId as SportId }
                : null,
          })
        } else {
          set({ challenges: updatedChallenges })
        }
      },

      setActiveSport: (sport) => set({ activeSport: sport }),
      clearRankUp: () => set({ showRankUp: null }),
      clearAuthError: () => set({ authError: null }),

      getTotalXp: () => {
        const { progress } = get()
        return Object.values(progress).reduce((sum, p) => sum + p.xp, 0)
      },

      getOverallRank: () => getRankByXp(get().getTotalXp()),
    }),
    {
      name: 'club-level-up-storage',
      partialize: (state) => {
        // En mode Supabase on ne persiste que le minimum UI ;
        // les données viennent du serveur.
        if (isSupabaseConfigured) {
          return {
            backendMode: state.backendMode,
          }
        }
        return {
          backendMode: state.backendMode,
          isAuthenticated: state.isAuthenticated,
          user: state.user,
          progress: state.progress,
          activities: state.activities,
          challenges: state.challenges,
          badges: state.badges,
        }
      },
    }
  )
)
