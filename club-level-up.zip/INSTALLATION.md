# Installation Club Level Up — Guide téléphone

L’application est une **PWA** ( Progressive Web App ).  
Elle s’installe sur Android comme une vraie appli, **sans Play Store**.

---

## Important à savoir

Le code de l’application est **terminé et fonctionnel**.

Pour l’installer sur ton téléphone, il faut d’abord qu’elle soit **mise en ligne** une fois (adresse https://…).  
Ensuite, en 10 secondes, tu l’ajoutes à ton écran d’accueil.

Sans mise en ligne, tu ne peux pas l’installer durablement depuis le téléphone seul.

---

## Partie A — Mettre l’app en ligne (une seule fois)

### Option la plus simple (ordinateur recommandé)

1. Sur un ordinateur, ouvre le dossier `club-level-up`
2. Dans un terminal :

```bash
npm install
npm run build
```

3. Va sur **https://app.netlify.com/drop** (compte gratuit)
4. Glisse-dépose le dossier **`dist`** qui a été créé
5. Netlify te donne une adresse du type :  
   `https://quelque-chose.netlify.app`
6. **Garde cette adresse** — c’est le lien de ton appli

### Alternative : Cloudflare Pages ou Vercel

Même principe : compte gratuit → déployer le dossier `dist` (ou relier un repo GitHub) → tu obtiens une URL https.

---

## Partie B — Installer sur ton téléphone Android (2 minutes)

1. Ouvre **Chrome** sur ton téléphone  
2. Va sur **l’adresse https** de ton appli (celle de Netlify / Cloudflare / Vercel)  
3. Attends que la page charge  
4. Appuie sur le menu **⋮** (en haut à droite)  
5. Choisis **« Installer l’application »**  
   ou **« Ajouter à l’écran d’accueil »**  
6. Confirme  

Une icône **Club Level Up / CLU** apparaît sur ton écran d’accueil.  
Tu l’ouvres comme n’importe quelle appli (plein écran).

---

## Utilisation immédiate (sans compte en ligne)

- Crée un compte dans l’app (mode démo si Supabase n’est pas configuré)
- Lance une course, gagne de l’XP, monte les rangs
- Les données restent sur le téléphone en mode démo

Pour des **comptes réels sauvegardés en ligne**, configure Supabase (fichier `SUPABASE.md`) puis redéploie.

---

## iPhone

1. Ouvre l’adresse de l’app dans **Safari**
2. Bouton **Partager** → **Sur l’écran d’accueil**
3. Ajouter

---

## Résumé ultra court

| Étape | Où | Action |
|-------|-----|--------|
| 1 | Ordinateur | `npm install` → `npm run build` |
| 2 | Navigateur | Déposer le dossier `dist` sur Netlify Drop |
| 3 | Téléphone Chrome | Ouvrir l’URL → Installer l’application |

Une fois l’étape 2 faite, tu n’as plus besoin de l’ordinateur pour utiliser l’appli au quotidien.
