-- ============================================================
-- CLUB LEVEL UP — Schéma Supabase (PostgreSQL)
-- À exécuter dans : Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- Extensions utiles
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ------------------------------------------------------------
-- 1. PROFILES (lié à auth.users)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  username TEXT UNIQUE NOT NULL,
  avatar_url TEXT,
  bio TEXT,
  country TEXT,
  city TEXT,
  sports TEXT[] NOT NULL DEFAULT '{}',
  initial_level JSONB NOT NULL DEFAULT '{}',
  goals TEXT[] NOT NULL DEFAULT '{}',
  privacy JSONB NOT NULL DEFAULT '{
    "showCountry": true,
    "showCity": false,
    "showStats": true,
    "showActivities": true
  }'::jsonb,
  is_premium BOOLEAN NOT NULL DEFAULT false,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'moderator', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 2. SPORT PROGRESS (XP + rang par discipline)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.sport_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  sport_id TEXT NOT NULL,
  xp INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
  rank_id INTEGER NOT NULL DEFAULT 1 CHECK (rank_id BETWEEN 1 AND 10),
  best_performances JSONB NOT NULL DEFAULT '{}',
  challenges_completed INTEGER NOT NULL DEFAULT 0,
  personal_records JSONB NOT NULL DEFAULT '{}',
  streak INTEGER NOT NULL DEFAULT 0,
  last_activity TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, sport_id)
);

-- ------------------------------------------------------------
-- 3. ACTIVITIES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  sport_id TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'session',
  title TEXT NOT NULL,
  date TIMESTAMPTZ NOT NULL DEFAULT now(),
  duration INTEGER NOT NULL DEFAULT 0, -- seconds
  distance NUMERIC, -- meters
  calories NUMERIC,
  stats JSONB NOT NULL DEFAULT '{}',
  notes TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  xp_earned INTEGER NOT NULL DEFAULT 0,
  gps_track JSONB, -- array of {lat, lng, timestamp} — never auto-publish publicly
  is_public BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_activities_user_date ON public.activities(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_activities_sport ON public.activities(sport_id);

-- ------------------------------------------------------------
-- 4. CHALLENGES (catalogue)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  sport_id TEXT NOT NULL, -- or 'all'
  category TEXT NOT NULL CHECK (category IN ('daily', 'weekly', 'monthly', 'community', 'premium')),
  difficulty INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
  target NUMERIC NOT NULL,
  unit TEXT NOT NULL,
  xp_reward INTEGER NOT NULL DEFAULT 0,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  conditions TEXT[] NOT NULL DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 5. USER CHALLENGE PROGRESS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.user_challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  challenge_id UUID NOT NULL REFERENCES public.challenges(id) ON DELETE CASCADE,
  progress NUMERIC NOT NULL DEFAULT 0,
  completed BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, challenge_id)
);

-- ------------------------------------------------------------
-- 6. BADGES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.badges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT NOT NULL,
  rarity TEXT NOT NULL CHECK (rarity IN ('common', 'rare', 'epic', 'legendary')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.user_badges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  badge_id UUID NOT NULL REFERENCES public.badges(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, badge_id)
);

-- ------------------------------------------------------------
-- 7. REPORTS (modération)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reported_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  activity_id UUID REFERENCES public.activities(id) ON DELETE SET NULL,
  reason TEXT NOT NULL,
  details TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'resolved', 'dismissed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 8. Trigger : créer le profil + progress sportives à l'inscription
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_username TEXT;
  v_sports TEXT[];
BEGIN
  v_username := COALESCE(
    NEW.raw_user_meta_data->>'username',
    split_part(NEW.email, '@', 1)
  );

  v_sports := COALESCE(
    ARRAY(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'sports')),
    ARRAY['running']::TEXT[]
  );

  INSERT INTO public.profiles (id, email, username, sports)
  VALUES (NEW.id, NEW.email, v_username, v_sports)
  ON CONFLICT (id) DO NOTHING;

  -- Initialiser une ligne de progress pour chaque sport choisi
  INSERT INTO public.sport_progress (user_id, sport_id)
  SELECT NEW.id, unnest(v_sports)
  ON CONFLICT (user_id, sport_id) DO NOTHING;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ------------------------------------------------------------
-- 9. updated_at automatique
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON public.profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS sport_progress_updated_at ON public.sport_progress;
CREATE TRIGGER sport_progress_updated_at
  BEFORE UPDATE ON public.sport_progress
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ------------------------------------------------------------
-- 10. ROW LEVEL SECURITY (RLS)
-- ------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sport_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- Profiles
CREATE POLICY "Public profiles are viewable by everyone"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Sport progress
CREATE POLICY "Users can view own progress"
  ON public.sport_progress FOR SELECT
  USING (auth.uid() = user_id OR true); -- public leaderboards later can restrict

CREATE POLICY "Users can update own progress"
  ON public.sport_progress FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own progress"
  ON public.sport_progress FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Activities
CREATE POLICY "Users can view own activities or public ones"
  ON public.activities FOR SELECT
  USING (auth.uid() = user_id OR is_public = true);

CREATE POLICY "Users can insert own activities"
  ON public.activities FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own activities"
  ON public.activities FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own activities"
  ON public.activities FOR DELETE
  USING (auth.uid() = user_id);

-- Challenges (catalogue public)
CREATE POLICY "Challenges are viewable by authenticated users"
  ON public.challenges FOR SELECT
  TO authenticated
  USING (is_active = true);

-- User challenges
CREATE POLICY "Users manage own challenge progress"
  ON public.user_challenges FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Badges
CREATE POLICY "Badges are public"
  ON public.badges FOR SELECT
  USING (true);

CREATE POLICY "Users can view own unlocked badges"
  ON public.user_badges FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert user badges"
  ON public.user_badges FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Reports
CREATE POLICY "Users can create reports"
  ON public.reports FOR INSERT
  WITH CHECK (auth.uid() = reporter_id);

CREATE POLICY "Users can view own reports"
  ON public.reports FOR SELECT
  USING (auth.uid() = reporter_id);

-- ------------------------------------------------------------
-- 11. Seed : quelques défis de départ
-- ------------------------------------------------------------
INSERT INTO public.challenges (title, description, sport_id, category, difficulty, target, unit, xp_reward, starts_at, ends_at, conditions)
VALUES
  (
    'Course matinale',
    'Cours au moins 3 km aujourd''hui',
    'running',
    'daily',
    2,
    3000,
    'm',
    80,
    now(),
    now() + interval '1 day',
    ARRAY['Distance minimale 3km', 'Validation GPS']
  ),
  (
    'Volume musculation',
    'Complète 5 séances de musculation cette semaine',
    'weightlifting',
    'weekly',
    3,
    5,
    'séances',
    250,
    now(),
    now() + interval '7 days',
    ARRAY['Minimum 4 exercices par séance']
  ),
  (
    '50 pompes',
    'Réalise 50 pompes (en plusieurs séries si besoin)',
    'streetworkout',
    'daily',
    2,
    50,
    'reps',
    60,
    now(),
    now() + interval '1 day',
    ARRAY['Forme correcte']
  ),
  (
    'Défi communautaire : 100km collectifs',
    'La communauté doit atteindre 100km de course cette semaine',
    'running',
    'community',
    3,
    100000,
    'm',
    150,
    now(),
    now() + interval '7 days',
    ARRAY['Participation active']
  )
ON CONFLICT DO NOTHING;

-- ============================================================
-- FIN DU SCHÉMA
-- Après exécution : Authentication → Providers → Email activé
-- Puis copier Project URL + anon key dans .env.local
-- ============================================================
