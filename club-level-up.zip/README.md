# CLUB LEVEL UP

**Entraîne-toi. Progresse. Prouve-le.**

Application web progressive (PWA) sportive gamifiée — React + TypeScript + Vite + Tailwind.

## Fonctionnalités opérationnelles (v1.0)

### ✅ Fonctionnel maintenant
- **Inscription / Connexion** — mode démo local **ou** Supabase réel (voir `SUPABASE.md`)
- **Profil utilisateur** personnalisable + confidentialité
- **10 rangs exclusifs** (Éveil → Ascendant) avec progression XP par discipline
- **Système XP** : performances, défis, régularité
- **7 disciplines** : Course, Musculation, Street Workout, Football, Tennis, Boxe, Basketball
- **Suivi GPS Course à pied** réel (Geolocation API navigateur)
  - Démarrer / Pause / Reprendre / Terminer
  - Distance, durée, allure, calories estimées
  - Historique et XP
- **Défis** quotidiens, hebdomadaires, communautaires
- **Classements** (données démo pour l’instant)
- **Coach IA** (règles + analyse locale des stats — prêt pour API réelle)
- **PWA** : manifest, service worker, installable Android
- **Design** violet électrique / noir / blanc, responsive, mobile-first
- **Logo CLU** intégré
- **Backend Supabase** : schéma SQL + RLS + client + auth branchés

### Backend Supabase
Suis le guide complet : **[SUPABASE.md](./SUPABASE.md)**

Résumé rapide :
1. Créer un projet gratuit sur supabase.com
2. Exécuter `supabase/schema.sql` dans le SQL Editor
3. Copier Project URL + anon key dans `.env.local`
4. `npm install && npm run dev` → badge **SUPABASE** en haut à droite

Sans `.env.local`, l’app reste en mode démo local (aucune config obligatoire pour tester l’UI).

### 🚧 Encore à brancher / enrichir
| Fonctionnalité | Manque |
|---------------|--------|
| Classements live | Requêtes agrégées + vues |
| Paiement Premium 2,99€ | Stripe / Paddle + vérifications légales |
| Giveaways | Financement + règlement juridique |
| Analyse vidéo Football | Modèle vision (non branché) |
| Modules avancés (équipes, matchs, programmes muscu complets) | UI + logique métier |
| Notifications push | Service worker + backend |
| Panneau admin | Routes + politiques RLS admin |
| Export / suppression compte RGPD | Edge Functions + UI |

## Stack technique (100% gratuit au démarrage)

- **Frontend** : React 19 + TypeScript + Vite
- **Style** : Tailwind CSS
- **État** : Zustand (persist localStorage)
- **Routing** : React Router
- **PWA** : vite-plugin-pwa
- **Backend recommandé** : Supabase (Auth + Postgres + Storage — free tier)
- **Hébergement** : Cloudflare Pages / Vercel / Netlify (gratuit)

## Installation locale

```bash
cd club-level-up
npm install
npm run dev
```

Ouvre http://localhost:5173

### Build production

```bash
npm run build
npm run preview
```

## Déploiement gratuit (Cloudflare Pages)

1. Crée un compte Cloudflare
2. Relie le repo GitHub (ou upload du dossier `dist` après `npm run build`)
3. Build command : `npm run build`
4. Output directory : `dist`
5. HTTPS automatique + PWA installable

## Passage en production (recommandé)

1. Créer un projet Supabase gratuit
2. Remplacer le store Zustand auth par `@supabase/supabase-js`
3. Tables : `profiles`, `activities`, `challenges`, `progress`, `reports`
4. RLS (Row Level Security) strict
5. Jamais de clés secrètes dans le frontend
6. Consentement géolocalisation + âge + RGPD

## Structure

```
src/
  components/   Layout, RankUpModal...
  pages/        Landing, Dashboard, RunningTracker, Challenges, Coach...
  stores/       useAppStore (Zustand)
  data/         ranks.ts, sports.ts
  types/        index.ts
public/
  logo.jpg
  icons/        (à générer pour PWA)
```

## Rangs

| Rang | XP min |
|------|--------|
| ÉVEIL | 0 |
| IMPULSION | 600 |
| ÉLAN | 1 800 |
| ASCENSION | 4 000 |
| DÉTERMINATION | 7 500 |
| PUISSANCE | 12 000 |
| DOMINANCE | 19 000 |
| ÉLITE | 29 000 |
| LÉGENDE | 43 000 |
| ASCENDANT | 65 000 |

Chaque discipline a sa propre barre d'XP.

## Sécurité & mineurs

- Géolocalisation = consentement explicite, désactivée par défaut
- Pas de position en temps réel publique
- Paramètres de visibilité
- Architecture prête pour suppression de compte et export
- Giveaways et paiements désactivés jusqu'à conformité légale

## Prochaines étapes recommandées

1. `npm install && npm run dev` → tester
2. Générer les icônes PWA 192/512 (à partir du logo)
3. Créer projet Supabase + brancher auth
4. Déployer sur Cloudflare Pages
5. Enrichir modules musculation / street workout / football
6. Brancher une vraie API Coach (optionnel)

---

**Club Level Up** — Version 1.0 fonctionnelle et extensible.
