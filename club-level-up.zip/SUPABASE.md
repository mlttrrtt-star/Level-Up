# Configuration Supabase — Club Level Up

Guide pas à pas pour activer le backend réel (gratuit).

Sans ces étapes, l’application fonctionne déjà en **mode démo local** (données dans le navigateur).

---

## 1. Créer un projet Supabase (gratuit)

1. Va sur [https://supabase.com](https://supabase.com) et crée un compte.
2. **New project**
   - Nom : `club-level-up`
   - Mot de passe base de données : choisis-en un fort (note-le)
   - Région : la plus proche (ex. `West EU` / Frankfurt)
3. Attends 1–2 minutes que le projet soit prêt.

---

## 2. Exécuter le schéma SQL

1. Dans le dashboard Supabase → **SQL Editor** → **New query**
2. Ouvre le fichier du projet : `supabase/schema.sql`
3. Copie **tout** le contenu et colle-le dans l’éditeur
4. Clique **Run**

Tu dois voir « Success ». Le schéma crée :

- `profiles` (lié à `auth.users`)
- `sport_progress` (XP + rang par discipline)
- `activities` (courses, séances…)
- `challenges` + `user_challenges`
- `badges` + `user_badges`
- `reports` (modération)
- Trigger automatique à l’inscription (profil + progress)
- **Row Level Security (RLS)** sur toutes les tables
- Quelques défis de départ

---

## 3. Configurer l’authentification

1. **Authentication** → **Providers** → **Email**
   - Active Email
   - Pour le développement : tu peux **désactiver** « Confirm email » (plus simple)
2. (Optionnel) **Authentication** → **URL Configuration**
   - Site URL : `http://localhost:5173` en dev
   - Redirect URLs : `http://localhost:5173/**`

---

## 4. Récupérer les clés publiques

1. **Project Settings** (icône engrenage) → **API**
2. Copie :
   - **Project URL** → `VITE_SUPABASE_URL`
   - **anon public** key → `VITE_SUPABASE_ANON_KEY`

⚠️ Utilise uniquement la clé **anon** (publique).  
**Ne mets jamais** la `service_role` key dans le frontend.

---

## 5. Brancher le frontend

À la racine du projet :

```bash
cp .env.example .env.local
```

Édite `.env.local` :

```env
VITE_SUPABASE_URL=https://TON_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Puis :

```bash
npm install
npm run dev
```

En haut à droite (mode dev) tu dois voir le badge **SUPABASE** au lieu de **LOCAL DEMO**.

---

## 6. Tester

1. Ouvre l’app → **Créer un compte**
2. Inscris-toi avec un vrai email + mot de passe (≥ 6 caractères)
3. Vérifie dans Supabase :
   - **Authentication** → **Users** : ton utilisateur
   - **Table Editor** → `profiles` : une ligne
   - **Table Editor** → `sport_progress` : une ligne par sport choisi
4. Lance une course GPS → une ligne apparaît dans `activities` et l’XP monte dans `sport_progress`

---

## 7. Déploiement (Cloudflare Pages / Vercel)

Ajoute les **mêmes variables** dans le dashboard d’hébergement :

| Variable | Valeur |
|----------|--------|
| `VITE_SUPABASE_URL` | ton Project URL |
| `VITE_SUPABASE_ANON_KEY` | ta clé anon |

Puis rebuild.

Pense aussi à ajouter l’URL de production dans **Authentication → URL Configuration**.

---

## Sécurité déjà en place

- RLS activé : chaque utilisateur ne lit/écrit que ses données (sauf profils publics limités)
- Parcours GPS : `is_public = false` par défaut — jamais publié automatiquement
- Pas de clé secrète dans le code
- Mode local conservé si les variables manquent (pas de crash)

---

## Free tier Supabase (limites actuelles)

- 500 Mo base de données
- 1 Go stockage fichiers
- Auth illimitée raisonnable pour démarrer
- Suffisant pour des milliers d’utilisateurs actifs au début

Quand tu grandiras : passer à un plan payant ou migrer (l’architecture SQL standard facilite la migration).

---

## Prochaines étapes backend possibles

- Bucket Storage pour avatars (`avatars`)
- Fonction Edge pour calcul XP anti-triche
- Realtime pour classements live
- Vue matérialisée leaderboard
- Compte admin + politiques RLS `role = 'admin'`

Le fichier `supabase/schema.sql` est le point de vérité du modèle de données.
